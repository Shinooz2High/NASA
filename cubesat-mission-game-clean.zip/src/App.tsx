import React from 'react';
import { useGameStore } from './store/gameStore';
import { ProgressBar } from './components/ui/ProgressBar';
import { LanguageToggle } from './components/ui/LanguageToggle';
import { StartScreen } from './components/game/StartScreen';
import { LevelSelect } from './components/game/LevelSelect';
import { ObjectiveSelect } from './components/game/ObjectiveSelect';
import { WavelengthSelect } from './components/game/WavelengthSelect';
import { InstrumentSelect } from './components/game/InstrumentSelect';
import { OpticsSelect } from './components/game/OpticsSelect';
import { SizeSelect } from './components/game/SizeSelect';
import { OrbitSelect } from './components/game/OrbitSelect';
import { SubsystemDesign } from './components/game/SubsystemDesign';
import { PointDesignDashboard } from './components/game/PointDesignDashboard';
import { LaunchAnimation } from './components/three/LaunchAnimation';
import { ResultsScreen } from './components/game/ResultsScreen';
import { NasaMatchScreen } from './components/game/NasaMatchScreen';
import { Satellite } from 'lucide-react';
import './i18n/config';

export const App: React.FC = () => {
  const { currentScreen, level, design, nextScreen, resetGame } = useGameStore();

  const renderScreen = () => {
    switch (currentScreen) {
      case 'start':
        return <StartScreen />;
      case 'level-select':
        return <LevelSelect />;
      case 'objective-select':
        return <ObjectiveSelect />;
      case 'wavelength-select':
        return <WavelengthSelect />;
      case 'instrument-select':
        return <InstrumentSelect />;
      case 'optics-select':
        return <OpticsSelect />;
      case 'size-select':
        return <SizeSelect />;
      case 'orbit-select':
        return <OrbitSelect />;
      case 'subsystem-design':
        return <SubsystemDesign />;
      case 'point-design':
        return <PointDesignDashboard />;
      case 'launch':
        return (
          <LaunchAnimation
            design={design}
            onComplete={() => nextScreen()}
          />
        );
      case 'results':
        return <ResultsScreen />;
      case 'nasa-match':
        return <NasaMatchScreen />;
      default:
        return <StartScreen />;
    }
  };

  return (
    <div className="w-full h-screen flex flex-col bg-slate-950 text-slate-100 overflow-hidden font-sans select-none">
      {/* ── Top Navigation Bar ───────────────────────────────────── */}
      <header className="w-full h-14 bg-slate-950/90 border-b border-cyan-500/20 px-4 md:px-8 flex items-center justify-between shrink-0 z-40 backdrop-blur-md">
        {/* Brand / Logo */}
        <div
          onClick={resetGame}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform shadow-md shadow-cyan-500/20">
            <Satellite className="w-4 h-4" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-black font-mono tracking-tight text-white group-hover:text-cyan-300 transition-colors">
              CubeSat Mission Designer
            </span>
            <span className="text-[10px] font-mono text-cyan-400 tracking-wider uppercase">
              NASA CSLI & Space Apps
            </span>
          </div>
        </div>

        {/* Header Right Items */}
        <div className="flex items-center gap-3">
          {currentScreen !== 'start' && (
            <span className="hidden sm:inline-block text-xs font-mono px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300">
              Level {level}
            </span>
          )}
          <LanguageToggle />
        </div>
      </header>

      {/* ── Progress Bar ─────────────────────────────────────────── */}
      <ProgressBar currentScreen={currentScreen} level={level} />

      {/* ── Active Screen Content Area ───────────────────────────── */}
      <main className="flex-1 overflow-y-auto relative">
        {renderScreen()}
      </main>
    </div>
  );
};

export default App;
