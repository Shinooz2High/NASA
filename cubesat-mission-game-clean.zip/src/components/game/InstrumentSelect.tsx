import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { INSTRUMENTS } from '../../data/instruments';
import { getCompatibleInstruments } from '../../data/compatibility';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import {
  ArrowLeft,
  ArrowRight,
  Camera,
  Layers,
  SunMedium,
  Flame,
  Compass,
  Activity,
  Radio,
  Radar,
  Scan,
  Target,
} from 'lucide-react';
import type { Instrument } from '../../types';

const ICON_MAP: Record<string, React.ElementType> = {
  Camera,
  Layers,
  SunMedium,
  Flame,
  Compass,
  Activity,
  Radio,
  Radar,
  Scan,
  Target,
};

export const InstrumentSelect: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { level, design, updateDesign, nextScreen, prevScreen } = useGameStore();

  const maxSelectable = level === 1 ? 1 : level === 2 ? 2 : 3;
  const compatibleInsts = getCompatibleInstruments(
    design.wavelengths,
    design.size
  );
  const selectedIds = design.instruments;

  const handleToggle = (inst: Instrument) => {
    if (selectedIds.includes(inst.id)) {
      updateDesign({
        instruments: selectedIds.filter((id) => id !== inst.id),
      });
    } else {
      if (level === 1) {
        updateDesign({ instruments: [inst.id] });
      } else if (selectedIds.length < maxSelectable) {
        updateDesign({ instruments: [...selectedIds, inst.id] });
      }
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto py-8 px-4 flex flex-col">
      {/* Title & Counter */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('instruments.title')}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {t('instruments.subtitle')}
          </p>
        </div>
        <div className="mt-4 md:mt-0 font-mono text-xs px-3.5 py-1.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 w-fit">
          Selected Instruments:{' '}
          <span className="font-bold text-white">
            {selectedIds.length} / {maxSelectable}
          </span>
        </div>
      </div>

      {/* Instruments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {INSTRUMENTS.map((inst) => {
          const isCompatible = compatibleInsts.some((ci) => ci.id === inst.id);
          const isSelected = selectedIds.includes(inst.id);
          const isDisabled =
            !isCompatible ||
            (!isSelected && selectedIds.length >= maxSelectable && level !== 1);

          const IconComponent = ICON_MAP[inst.icon] || Camera;

          return (
            <Card
              key={inst.id}
              selected={isSelected}
              disabled={isDisabled}
              onClick={() => handleToggle(inst)}
              className="flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-slate-800 text-cyan-400">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {inst.type}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-cyan-400 font-semibold">
                    {inst.volume}U Bus
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-100 mb-2 leading-snug">
                  {inst.name[lang] || inst.name.en}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {inst.description[lang] || inst.description.en}
                </p>
              </div>

              {/* Engineering Stats Box */}
              <div className="grid grid-cols-3 gap-2 p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 text-center font-mono">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">
                    {t('instruments.mass')}
                  </div>
                  <div className="text-xs font-bold text-slate-200">
                    {inst.mass} kg
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">
                    {t('instruments.power')}
                  </div>
                  <div className="text-xs font-bold text-amber-400">
                    {inst.power} W
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">
                    {t('instruments.dataRate')}
                  </div>
                  <div className="text-xs font-bold text-cyan-400">
                    {inst.dataRate} Mb/s
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={ArrowRight}
          iconPosition="right"
          disabled={selectedIds.length === 0}
          onClick={nextScreen}
          className="shadow-lg shadow-cyan-500/25"
        >
          {t('nav.next')}
        </Button>
      </div>
    </div>
  );
};
