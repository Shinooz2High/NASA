import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { ArrowRight, Compass, Wrench, Crown } from 'lucide-react';
import type { GameLevel } from '../../types';

export const LevelSelect: React.FC = () => {
  const { t } = useTranslation();
  const { level, setLevel, nextScreen } = useGameStore();

  const levels: Array<{
    id: GameLevel;
    icon: React.ElementType;
    titleKey: string;
    descKey: string;
    tagKey: string;
    color: string;
    features: string[];
  }> = [
    {
      id: 1,
      icon: Compass,
      titleKey: 'levels.level1.title',
      descKey: 'levels.level1.desc',
      tagKey: 'levels.level1.tag',
      color: 'from-emerald-500/20 to-teal-500/5 text-emerald-400 border-emerald-500/30',
      features: [
        '1 Scientific Objective',
        '1 Wavelength Band & 1 Sensor',
        'Standard 3U CubeSat Bus',
        'Automated Subsystem Presets',
        'Guided Mission Orbit',
      ],
    },
    {
      id: 2,
      icon: Wrench,
      titleKey: 'levels.level2.title',
      descKey: 'levels.level2.desc',
      tagKey: 'levels.level2.tag',
      color: 'from-cyan-500/20 to-blue-500/5 text-cyan-400 border-cyan-500/30',
      features: [
        'Up to 2 Objectives & Bands',
        'Telescope Optics & Antenna Dishes',
        'Scalable Bus: 1U, 2U, 3U, or 6U',
        'Custom EPS Solar Cells & Batteries',
        'RF Downlink Band Selection',
      ],
    },
    {
      id: 3,
      icon: Crown,
      titleKey: 'levels.level3.title',
      descKey: 'levels.level3.desc',
      tagKey: 'levels.level3.tag',
      color: 'from-purple-500/20 to-pink-500/5 text-purple-400 border-purple-500/30',
      features: [
        'Up to 3 Objectives (Multidisciplinary)',
        'Full 1U to 12U Deep-Space Bus',
        'Ion / Hall Thruster Propulsion',
        'Thermal MLI Blankets & Heaters',
        'NASA SSCM Mission Cost Modeling',
      ],
    },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 flex flex-col items-center">
      <div className="text-center max-w-2xl mb-8">
        <h2 className="text-3xl font-extrabold text-white mb-2 tracking-tight">
          {t('levels.title')}
        </h2>
        <p className="text-sm text-slate-400">{t('levels.subtitle')}</p>
      </div>

      {/* Level Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mb-10">
        {levels.map((lvl) => {
          const Icon = lvl.icon;
          const isSelected = level === lvl.id;

          return (
            <Card
              key={lvl.id}
              selected={isSelected}
              onClick={() => setLevel(lvl.id)}
              className="flex flex-col justify-between h-full hover:border-cyan-400/60"
            >
              <div>
                {/* Level Header */}
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br ${lvl.color} border shadow-lg`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300">
                    {t(lvl.tagKey)}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-100 mb-2">
                  {t(lvl.titleKey)}
                </h3>
                <p className="text-xs text-slate-400 mb-5 leading-relaxed">
                  {t(lvl.descKey)}
                </p>

                {/* Feature Bullet points */}
                <div className="space-y-2 border-t border-slate-800 pt-4">
                  {lvl.features.map((feat, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-2 text-xs text-slate-300"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-3">
                <Button
                  variant={isSelected ? 'primary' : 'secondary'}
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setLevel(lvl.id);
                    nextScreen();
                  }}
                >
                  {isSelected ? 'Selected' : 'Choose Level'}
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      <Button
        variant="primary"
        size="lg"
        icon={ArrowRight}
        iconPosition="right"
        onClick={nextScreen}
        className="w-48 shadow-lg shadow-cyan-500/25"
      >
        {t('nav.next')}
      </Button>
    </div>
  );
};
