import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import {
  ExternalLink,
  RotateCcw,
  Sparkles,
  CheckCircle,
  Bookmark,
  Share2,
} from 'lucide-react';
import { saveDesignToStorage, exportDesignAsJson } from '../../store/saveManager';

export const NasaMatchScreen: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { design, matchResults, resetGame } = useGameStore();

  const handleSave = () => {
    saveDesignToStorage(design);
    alert(t('nasaMatch.saveSuccess'));
  };

  const handleShare = () => {
    const jsonStr = exportDesignAsJson(design);
    navigator.clipboard.writeText(jsonStr);
    alert('Design JSON copied to clipboard!');
  };

  return (
    <div className="w-full max-w-6xl mx-auto py-8 px-4 flex flex-col">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-300 text-xs font-mono mb-3">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>Spaceflight Heritage Analysis</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight mb-2">
          {t('nasaMatch.title')}
        </h2>
        <p className="text-sm text-slate-400">
          {t('nasaMatch.subtitle')}
        </p>
      </div>

      {/* ── Top 3 NASA Mission Cards ───────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
        {matchResults.map((match, idx) => {
          const { mission, overallScore, matchReasons } = match;

          return (
            <Card
              key={mission.id}
              className="flex flex-col justify-between border-slate-700/80 hover:border-cyan-400/80 shadow-2xl relative overflow-hidden"
            >
              {/* Rank Banner */}
              <div className="absolute top-0 right-0 bg-gradient-to-l from-cyan-500 to-transparent text-slate-950 font-black text-xs font-mono px-4 py-1">
                #{idx + 1} MATCH
              </div>

              <div>
                {/* Header */}
                <div className="flex items-center justify-between mb-3 mt-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {mission.launchYear}
                    </span>
                    {mission.isCubesat && (
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-950/70 text-amber-400 border border-amber-800/40 font-semibold">
                        CubeSat
                      </span>
                    )}
                  </div>
                  <div className="text-xl font-black font-mono text-cyan-400">
                    {overallScore}%
                  </div>
                </div>

                <h3 className="text-lg font-bold text-white mb-2 leading-snug">
                  {mission.name}
                </h3>

                <p className="text-xs text-slate-400 leading-relaxed mb-5">
                  {mission.description[lang] || mission.description.en}
                </p>

                {/* Subsystem Match Comparison Breakdown */}
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2 mb-4 font-mono text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Domain Match:</span>
                    <span className="text-slate-200 font-bold">
                      {match.domainScore}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Wavelengths:</span>
                    <span className="text-slate-200 font-bold">
                      {match.wavelengthScore}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Orbit Regime:</span>
                    <span className="text-slate-200 font-bold">
                      {match.orbitScore}% ({mission.orbit})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Instruments:</span>
                    <span className="text-slate-200 font-bold">
                      {match.instrumentScore}%
                    </span>
                  </div>
                </div>

                {/* Why it matches */}
                <div className="space-y-1.5 border-t border-slate-800 pt-3 mb-4">
                  <span className="text-[11px] font-mono text-slate-500 block mb-1">
                    {t('nasaMatch.whyMatch')}:
                  </span>
                  {matchReasons.map((reason, rIdx) => (
                    <div
                      key={rIdx}
                      className="flex items-start gap-1.5 text-xs text-slate-300"
                    >
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{reason[lang] || reason.en}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* NASA link */}
              <div className="pt-2 border-t border-slate-800/80">
                <a
                  href={mission.nasaUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-cyan-300 text-xs font-mono font-medium transition-colors"
                >
                  <span>{t('nasaMatch.learnMore')}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </Card>
          );
        })}
      </div>

      {/* ── Footer Actions ────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-slate-800">
        <div className="flex items-center gap-3">
          <Button variant="secondary" icon={Bookmark} onClick={handleSave}>
            {t('nav.save')}
          </Button>
          <Button variant="secondary" icon={Share2} onClick={handleShare}>
            {t('nasaMatch.share')}
          </Button>
        </div>

        <Button
          variant="primary"
          size="lg"
          icon={RotateCcw}
          onClick={resetGame}
          className="shadow-xl shadow-cyan-500/25"
        >
          {t('nav.restart')}
        </Button>
      </div>
    </div>
  );
};
