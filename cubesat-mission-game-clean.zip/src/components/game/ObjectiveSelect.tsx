import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { OBJECTIVES } from '../../data/objectives';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import type { ScientificObjective } from '../../types';

export const ObjectiveSelect: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { level, design, updateDesign, nextScreen, prevScreen } = useGameStore();

  const maxSelectable = level === 1 ? 1 : level === 2 ? 2 : 3;
  const selectedIds = design.objectives;

  const handleToggle = (objective: ScientificObjective) => {
    if (selectedIds.includes(objective.id)) {
      updateDesign({
        objectives: selectedIds.filter((id) => id !== objective.id),
      });
    } else {
      if (level === 1) {
        // Replace single selection
        updateDesign({ objectives: [objective.id] });
      } else if (selectedIds.length < maxSelectable) {
        updateDesign({ objectives: [...selectedIds, objective.id] });
      }
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto py-8 px-4 flex flex-col">
      {/* Title & Counter */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('objectives.title')}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {t('objectives.subtitle')}
          </p>
        </div>
        <div className="mt-4 md:mt-0 font-mono text-xs px-3.5 py-1.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 w-fit">
          {t('objectives.selectLimit', { limit: maxSelectable })}:{' '}
          <span className="font-bold text-white">
            {selectedIds.length} / {maxSelectable}
          </span>
        </div>
      </div>

      {/* Objectives Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {OBJECTIVES.map((obj) => {
          const isSelected = selectedIds.includes(obj.id);
          const isDisabled =
            !isSelected && selectedIds.length >= maxSelectable && level !== 1;

          return (
            <Card
              key={obj.id}
              selected={isSelected}
              disabled={isDisabled}
              onClick={() => handleToggle(obj)}
              className="flex flex-col justify-between"
            >
              <div>
                {/* Header domain & difficulty */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] uppercase tracking-wider font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                    {obj.domain.replace('-', ' ')}
                  </span>
                  <span className="text-xs font-mono text-amber-400">
                    {'★'.repeat(obj.difficulty)}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-100 mb-2 leading-snug">
                  {obj.name[lang] || obj.name.en}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {obj.description[lang] || obj.description.en}
                </p>
              </div>

              {/* Tags footer */}
              <div className="space-y-2 border-t border-slate-800/80 pt-3">
                <div className="flex flex-wrap items-center gap-1 text-[11px]">
                  <span className="text-slate-500 font-mono">Bands:</span>
                  {obj.compatibleWavelengths.map((w) => (
                    <span
                      key={w}
                      className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-mono"
                    >
                      {w}
                    </span>
                  ))}
                </div>
                <div className="flex flex-wrap items-center gap-1 text-[11px]">
                  <span className="text-slate-500 font-mono">Orbits:</span>
                  {obj.suggestedOrbits.map((orb) => (
                    <span
                      key={orb}
                      className="px-1.5 py-0.5 rounded bg-cyan-950/60 text-cyan-300 text-[10px] font-mono border border-cyan-800/40"
                    >
                      {orb}
                    </span>
                  ))}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={ArrowRight}
          iconPosition="right"
          disabled={selectedIds.length === 0}
          onClick={nextScreen}
          className="shadow-lg shadow-cyan-500/25"
        >
          {t('nav.next')}
        </Button>
      </div>
    </div>
  );
};
