import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { OPTICS } from '../../data/optics';
import { getCompatibleOptics } from '../../data/compatibility';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { ArrowLeft, ArrowRight, Eye, Radio } from 'lucide-react';
import type { OpticalSystem } from '../../types';

export const OpticsSelect: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { design, updateDesign, nextScreen, prevScreen } = useGameStore();

  const compatibleOptics = getCompatibleOptics(design.wavelengths, design.size);
  const selectedIds = design.optics;

  const handleToggle = (opt: OpticalSystem) => {
    if (selectedIds.includes(opt.id)) {
      updateDesign({
        optics: selectedIds.filter((id) => id !== opt.id),
      });
    } else {
      // Single optics selection for payload
      updateDesign({ optics: [opt.id] });
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 flex flex-col">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('optics.title')}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {t('optics.subtitle')}
          </p>
        </div>
        <div className="mt-4 md:mt-0 font-mono text-xs px-3.5 py-1.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 w-fit">
          Selected Optics:{' '}
          <span className="font-bold text-white">
            {selectedIds.length} / 1
          </span>
        </div>
      </div>

      {/* Optics Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {OPTICS.map((opt) => {
          const isCompatible = compatibleOptics.some((co) => co.id === opt.id);
          const isSelected = selectedIds.includes(opt.id);

          return (
            <Card
              key={opt.id}
              selected={isSelected}
              disabled={!isCompatible}
              onClick={() => handleToggle(opt)}
              className="flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-slate-800 text-cyan-400">
                      {opt.type === 'reflector' || opt.type === 'refractor' ? (
                        <Eye className="w-5 h-5" />
                      ) : (
                        <Radio className="w-5 h-5" />
                      )}
                    </div>
                    <span className="text-[11px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {opt.type.replace('-', ' ')}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-cyan-400 font-semibold">
                    {opt.volume}U
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-100 mb-2 leading-snug">
                  {opt.name[lang] || opt.name.en}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {opt.description[lang] || opt.description.en}
                </p>
              </div>

              {/* Engineering Stats Box */}
              <div className="grid grid-cols-3 gap-2 p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 text-center font-mono">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">
                    Aperture
                  </div>
                  <div className="text-xs font-bold text-slate-200">
                    {opt.aperture} m
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">
                    FOV
                  </div>
                  <div className="text-xs font-bold text-cyan-400">
                    {opt.fov}°
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase">
                    Mass
                  </div>
                  <div className="text-xs font-bold text-amber-400">
                    {opt.mass} kg
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={ArrowRight}
          iconPosition="right"
          onClick={nextScreen}
          className="shadow-lg shadow-cyan-500/25"
        >
          {t('nav.next')}
        </Button>
      </div>
    </div>
  );
};
