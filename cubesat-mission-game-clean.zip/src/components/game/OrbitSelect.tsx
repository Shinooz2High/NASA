import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { getCompatibleOrbits } from '../../data/compatibility';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { OrbitScene } from '../three/OrbitScene';
import { ArrowLeft, ArrowRight, Globe } from 'lucide-react';
import type { OrbitType } from '../../types';

export const OrbitSelect: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { design, updateDesign, nextScreen, prevScreen } = useGameStore();

  const sortedOrbits = getCompatibleOrbits(design.objectives);

  const handleSelect = (orbitType: OrbitType, altitude: number) => {
    updateDesign({
      orbit: orbitType,
      orbitAltitude: altitude,
    });
  };

  return (
    <div className="w-full max-w-6xl mx-auto py-8 px-4 flex flex-col">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('orbit.title')}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {t('orbit.subtitle')}
          </p>
        </div>
        <div className="mt-4 md:mt-0 font-mono text-xs px-3.5 py-1.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 w-fit">
          Current Orbit:{' '}
          <span className="font-bold text-white">{design.orbit}</span>
        </div>
      </div>

      {/* 3D Orbit Trajectory Visualization */}
      <div className="mb-8 shadow-2xl rounded-2xl overflow-hidden border border-slate-800">
        <OrbitScene design={design} className="w-full h-72 md:h-80" />
      </div>

      {/* Orbit Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {sortedOrbits.map((orb) => {
          const isSelected = design.orbit === orb.type;

          return (
            <Card
              key={orb.type}
              selected={isSelected}
              onClick={() => handleSelect(orb.type, orb.altitude)}
              className="flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-cyan-400" />
                    <h3 className="text-base font-bold text-slate-100">
                      {orb.name[lang] || orb.name.en}
                    </h3>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {orb.description[lang] || orb.description.en}
                </p>
              </div>

              {/* Orbital Telemetry Parameters */}
              <div className="grid grid-cols-2 gap-2 p-2.5 rounded-lg bg-slate-950/60 border border-slate-800 font-mono text-[11px]">
                <div>
                  <span className="text-slate-500 block">Period:</span>
                  <span className="text-slate-200 font-semibold">
                    {orb.period > 1000
                      ? `${(orb.period / 60).toFixed(1)} hrs`
                      : `${orb.period} min`}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Eclipse:</span>
                  <span className="text-amber-400 font-semibold">
                    {Math.round(orb.eclipseFraction * 100)}% of orbit
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Inclination:</span>
                  <span className="text-slate-200 font-semibold">
                    {orb.inclination}°
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Altitude:</span>
                  <span className="text-cyan-400 font-semibold">
                    {orb.altitude.toLocaleString()} km
                  </span>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={ArrowRight}
          iconPosition="right"
          onClick={nextScreen}
          className="shadow-lg shadow-cyan-500/25"
        >
          {t('nav.next')}
        </Button>
      </div>
    </div>
  );
};
