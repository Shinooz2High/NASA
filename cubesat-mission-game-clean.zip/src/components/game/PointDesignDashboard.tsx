import React, { useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { CubeSatModel } from '../three/CubeSatModel';
import { StatusBadge } from '../ui/StatusBadge';
import { Button } from '../ui/Button';
import {
  ArrowLeft,
  Rocket,
  Zap,
  Radio,
  Thermometer,
  Scale,
  Flame,
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Info,
} from 'lucide-react';
import type { PointDesignResult } from '../../types';

export const PointDesignDashboard: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { design, pointDesignResult, runPointDesign, nextScreen, prevScreen } =
    useGameStore();

  const [pd, setPd] = useState<PointDesignResult | null>(pointDesignResult);

  useEffect(() => {
    const res = runPointDesign();
    setPd(res);
  }, []);

  if (!pd) return null;

  return (
    <div className="w-full max-w-6xl mx-auto py-8 px-4 flex flex-col">
      {/* ── Header & Feasibility Banner ────────────────────────────── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 pb-4 border-b border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-cyan-950 text-cyan-300 border border-cyan-800/40">
              NASA JPL CML 3/4
            </span>
            <span className="text-xs font-mono text-slate-400">
              Point Design Review
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('pointDesign.title')}
          </h2>
          <p className="text-xs md:text-sm text-slate-400 mt-1">
            {t('pointDesign.subtitle')}
          </p>
        </div>

        {/* Overall Feasibility Badge */}
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <div className="text-center font-mono">
            <div className="text-2xl md:text-3xl font-black text-cyan-400">
              {pd.feasibilityScore}
              <span className="text-xs text-slate-500">/100</span>
            </div>
            <div className="text-[10px] uppercase tracking-wider text-slate-400">
              Score
            </div>
          </div>
          <div className="h-10 w-[1px] bg-slate-800" />
          <div className="flex flex-col">
            <StatusBadge
              status={
                pd.overallFeasibility === 'feasible'
                  ? 'ok'
                  : pd.overallFeasibility === 'marginal'
                  ? 'warning'
                  : 'critical'
              }
              label={
                pd.overallFeasibility === 'feasible'
                  ? t('pointDesign.feasible')
                  : pd.overallFeasibility === 'marginal'
                  ? t('pointDesign.marginal')
                  : t('pointDesign.infeasible')
              }
            />
          </div>
        </div>
      </div>

      {/* ── Main Grid: 3D Preview + Budgets ───────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Left Column: 3D Interactive Model */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/60 border border-slate-800 p-4 flex flex-col justify-between backdrop-blur-md shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase tracking-wider text-cyan-300">
              Virtual Flight Hardware
            </span>
            <span className="text-xs font-mono text-slate-400">
              {design.size} Bus
            </span>
          </div>

          <div className="w-full h-64 md:h-80 rounded-xl overflow-hidden bg-slate-950/80 border border-slate-800">
            <Canvas camera={{ position: [0, 0, 4.5], fov: 45 }}>
              <ambientLight intensity={0.4} />
              <directionalLight position={[10, 10, 5]} intensity={1.5} />
              <pointLight position={[-10, -5, -5]} color="#00d4ff" intensity={0.8} />
              <Stars radius={60} depth={30} count={1500} factor={3} saturation={0} />
              <CubeSatModel design={design} scale={1.1} />
              <OrbitControls enableZoom={true} autoRotate autoRotateSpeed={0.6} />
            </Canvas>
          </div>

          <div className="mt-3 text-center text-[11px] font-mono text-slate-500">
            Click & drag to rotate spacecraft in 3D
          </div>
        </div>

        {/* Right Columns: Subsystem Budgets 2x2 Grid */}
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 1. POWER BUDGET */}
          <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                  <Zap className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-200">
                  {t('pointDesign.powerBudget')}
                </h4>
              </div>
              <StatusBadge status={pd.power.status} size="sm" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono mb-2">
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.genPower')}
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.power.powerGeneratedSunlit} W
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.avgPower')}
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.power.powerGenerated} W
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.reqPower')}
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.power.totalPowerRequired} W
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.margin')}
                </span>
                <span
                  className={`font-bold ${
                    pd.power.margin >= 20 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {pd.power.margin}%
                </span>
              </div>
            </div>

            <div className="text-[11px] font-mono text-slate-400">
              Battery DOD: {pd.power.batteryDepthOfDischarge}% (Life: ~{pd.power.batteryLifeCycles.toLocaleString()} cycles)
            </div>
          </div>

          {/* 2. LINK BUDGET */}
          <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400">
                  <Radio className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-200">
                  {t('pointDesign.linkBudget')}
                </h4>
              </div>
              <StatusBadge status={pd.link.status} size="sm" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono mb-2">
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.eirp')}
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.link.eirp} dBW
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.pathLoss')}
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.link.pathLoss} dB
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.snr')}
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.link.snr} dB
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.margin')}
                </span>
                <span
                  className={`font-bold ${
                    pd.link.margin >= 3.0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  +{pd.link.margin} dB
                </span>
              </div>
            </div>

            <div className="text-[11px] font-mono text-cyan-300">
              Throughput: {pd.link.dataRate} kbps • Vol: {pd.link.dailyDataVolume} MB/day
            </div>
          </div>

          {/* 3. THERMAL ANALYSIS */}
          <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
                  <Thermometer className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-200">
                  {t('pointDesign.thermalAnalysis')}
                </h4>
              </div>
              <StatusBadge status={pd.thermal.status} size="sm" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono mb-2">
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.hotTemp')}
                </span>
                <span className="text-amber-400 font-bold">
                  +{pd.thermal.hotCaseTemp}°C
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.coldTemp')}
                </span>
                <span className="text-cyan-400 font-bold">
                  {pd.thermal.coldCaseTemp}°C
                </span>
              </div>
            </div>

            <div className="text-[11px] font-mono text-slate-400">
              Average: {pd.thermal.averageTemp}°C • Safe Range: [-20°C, +55°C]
            </div>
          </div>

          {/* 4. MASS BUDGET */}
          <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-teal-500/20 text-teal-400">
                  <Scale className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-bold text-slate-200">
                  {t('pointDesign.massBudget')}
                </h4>
              </div>
              <StatusBadge status={pd.mass.status} size="sm" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono mb-2">
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  {t('pointDesign.totalMass')}
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.mass.totalMass} kg
                </span>
              </div>
              <div className="p-2 rounded bg-slate-950/50">
                <span className="text-slate-500 block text-[10px]">
                  Deployer Max
                </span>
                <span className="text-slate-100 font-bold">
                  {pd.mass.maxMass} kg
                </span>
              </div>
            </div>

            <div className="text-[11px] font-mono text-slate-400">
              Payload: {pd.mass.payload} kg • Mass Margin: {pd.mass.margin}%
            </div>
          </div>
        </div>
      </div>

      {/* ── Cost & Propulsion Sub-strip ───────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/20 text-green-400">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono text-slate-400 uppercase">
                {t('pointDesign.totalCost')}
              </span>
              <div className="text-lg font-bold text-slate-100 font-mono">
                ${pd.cost.totalCost.toLocaleString()} USD
              </div>
            </div>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-slate-800 text-slate-300">
            {pd.cost.costCategory.toUpperCase()} COST
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/20 text-purple-400">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-mono text-slate-400 uppercase">
                {t('pointDesign.deltaV')}
              </span>
              <div className="text-lg font-bold text-slate-100 font-mono">
                {pd.propulsion.totalDeltaV} m/s
              </div>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {pd.propulsion.maneuverCapability[0] || 'Passive decay'}
          </span>
        </div>
      </div>

      {/* ── Engineering Recommendations ───────────────────────────── */}
      <div className="mb-8 p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
        <h4 className="text-sm font-bold text-slate-200 mb-3 flex items-center gap-2">
          <Info className="w-4 h-4 text-cyan-400" />
          {t('pointDesign.recommendations')}
        </h4>
        <div className="space-y-2">
          {pd.recommendations.map((rec, i) => (
            <div
              key={i}
              className={`p-3 rounded-xl border text-xs leading-relaxed flex items-start gap-2.5 ${
                rec.severity === 'critical'
                  ? 'bg-rose-950/30 border-rose-800/50 text-rose-200'
                  : rec.severity === 'warning'
                  ? 'bg-amber-950/30 border-amber-800/50 text-amber-200'
                  : 'bg-slate-950/40 border-slate-800 text-slate-300'
              }`}
            >
              {rec.severity === 'critical' ? (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              ) : rec.severity === 'warning' ? (
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              )}
              <div>
                <span className="font-bold mr-1.5 uppercase tracking-wider text-[10px]">
                  [{rec.category}]
                </span>
                {rec.message[lang] || rec.message.en}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Navigation Buttons ────────────────────────────────────── */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={Rocket}
          iconPosition="right"
          size="lg"
          onClick={nextScreen}
          className="shadow-xl shadow-cyan-500/30"
        >
          {t('nav.launch')}
        </Button>
      </div>
    </div>
  );
};
