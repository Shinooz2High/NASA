import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { Button } from '../ui/Button';
import {
  Sparkles,
  Trophy,
  Database,
  Calendar,
  Globe,
  Activity,
  ArrowRight,
  Bookmark,
  CheckCircle2,
} from 'lucide-react';
import { saveDesignToStorage } from '../../store/saveManager';

export const ResultsScreen: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { design, scienceResult, runMissionCompletion, nextScreen } =
    useGameStore();

  useEffect(() => {
    if (!scienceResult) {
      runMissionCompletion();
    }
  }, [scienceResult, runMissionCompletion]);

  if (!scienceResult) return null;

  const handleSave = () => {
    saveDesignToStorage(design);
    alert(t('nasaMatch.saveSuccess'));
  };

  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 flex flex-col">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950 border border-cyan-500/30 text-cyan-300 text-xs font-mono mb-3">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>NASA Science Operations Complete</span>
        </div>
        <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight mb-2">
          {t('results.title')}
        </h2>
        <p className="text-sm text-slate-400">
          {t('results.subtitle')}
        </p>
      </div>

      {/* ── Top Score & Metric Badges ─────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        {/* Science Score Box */}
        <div className="md:col-span-1 p-6 rounded-2xl bg-gradient-to-br from-cyan-950/60 to-slate-900 border border-cyan-500/40 flex flex-col items-center justify-center text-center shadow-xl shadow-cyan-950/40">
          <Trophy className="w-8 h-8 text-amber-400 mb-2" />
          <div className="text-4xl md:text-5xl font-black text-cyan-300 font-mono tracking-tight">
            {scienceResult.scienceScore}
            <span className="text-sm text-slate-400">/100</span>
          </div>
          <span className="text-xs font-mono uppercase tracking-wider text-slate-300 mt-1">
            {t('results.scienceScore')}
          </span>
        </div>

        {/* 3 Metrics Cards */}
        <div className="md:col-span-3 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center gap-2 text-cyan-400 mb-2">
              <Database className="w-5 h-5" />
              <span className="text-xs font-mono uppercase text-slate-400">
                {t('results.dailyData')}
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100">
              {scienceResult.dataCollectedPerDay.toLocaleString()} MB/day
            </div>
            <span className="text-[11px] font-mono text-slate-500">
              Total: {scienceResult.totalDataMission} GB over mission
            </span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center gap-2 text-emerald-400 mb-2">
              <Calendar className="w-5 h-5" />
              <span className="text-xs font-mono uppercase text-slate-400">
                {t('results.missionLife')}
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100">
              {scienceResult.missionLifetime} months
            </div>
            <span className="text-[11px] font-mono text-slate-500">
              Duty Cycle: {scienceResult.dutyCycle}%
            </span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center gap-2 text-purple-400 mb-2">
              <Globe className="w-5 h-5" />
              <span className="text-xs font-mono uppercase text-slate-400">
                {t('results.coverage')}
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-slate-100">
              {scienceResult.coverage}%
            </div>
            <span className="text-[11px] font-mono text-slate-500">
              Target orbital swath
            </span>
          </div>
        </div>
      </div>

      {/* ── Scientific Discoveries Narrative ───────────────────────── */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 mb-8 shadow-xl">
        <h3 className="text-base font-bold text-slate-200 mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400" />
          {t('results.discoveries')}
        </h3>

        <div className="space-y-3">
          {scienceResult.discoveries.map((disc, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-start gap-3"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1">
                  <h4 className="text-sm font-bold text-slate-100">
                    {disc.title[lang] || disc.title.en}
                  </h4>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-800/30 w-fit">
                    {t('results.probability')}: {Math.round(disc.probability * 100)}%
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {disc.description[lang] || disc.description.en}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Action Buttons ────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
        <Button variant="secondary" icon={Bookmark} onClick={handleSave}>
          {t('nav.save')}
        </Button>

        <Button
          variant="primary"
          size="lg"
          icon={ArrowRight}
          iconPosition="right"
          onClick={nextScreen}
          className="shadow-xl shadow-cyan-500/25"
        >
          {t('results.viewAnalogs')}
        </Button>
      </div>
    </div>
  );
};
