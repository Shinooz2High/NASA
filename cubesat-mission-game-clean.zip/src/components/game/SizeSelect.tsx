import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { ArrowLeft, ArrowRight, Box } from 'lucide-react';
import type { CubeSatSize } from '../../types';

interface SizeSpec {
  size: CubeSatSize;
  dimensions: string;
  maxMass: number;
  payloadCapacity: string;
  description: { en: string; vi: string };
  recommendedFor: string;
}

const SIZE_SPECS: SizeSpec[] = [
  {
    size: '1U',
    dimensions: '10 × 10 × 10 cm',
    maxMass: 2.0,
    payloadCapacity: '0.3 – 0.5 U',
    description: {
      en: 'Ultra-compact standard form factor. Ideal for single sensor technology demos, radiation dosimeters, or student missions.',
      vi: 'Khung siêu nhỏ gọn tiêu chuẩn. Lý tưởng cho thử nghiệm công nghệ 1 cảm biến, máy đo bức xạ hoặc vệ tinh giáo dục.',
    },
    recommendedFor: 'Tech Demos, Single Sensors',
  },
  {
    size: '2U',
    dimensions: '10 × 10 × 22.7 cm',
    maxMass: 4.0,
    payloadCapacity: '0.8 – 1.2 U',
    description: {
      en: 'Double-unit bus allowing dedicated camera optics alongside standard avionics and battery packs.',
      vi: 'Khung 2 đơn vị cho phép lắp đặt cụm thấu kính camera chuyên dụng cùng hệ thống avionics và pin tiêu chuẩn.',
    },
    recommendedFor: 'Basic Remote Sensing',
  },
  {
    size: '3U',
    dimensions: '10 × 10 × 34 cm',
    maxMass: 6.0,
    payloadCapacity: '1.5 – 2.0 U',
    description: {
      en: 'The industry-standard scientific workhorse. Accommodates multi-spectral cameras, deployable arrays, and precision ADCS reaction wheels.',
      vi: 'Tiêu chuẩn khoa học phổ biến nhất thế giới. Đủ không gian cho camera đa phổ, tấm pin bung và bánh đà phản lực ADCS.',
    },
    recommendedFor: 'Earth Imaging & Science',
  },
  {
    size: '6U',
    dimensions: '10 × 22.7 × 34 cm',
    maxMass: 12.0,
    payloadCapacity: '3.0 – 4.0 U',
    description: {
      en: 'High-performance bus for interplanetary missions (heritage: NASA MarCO, LunaH-Map). Supports cold-gas propulsion and high-gain Ka/X-band dishes.',
      vi: 'Khung hiệu năng cao cho nhiệm vụ liên hành tinh (tiền lệ: NASA MarCO). Hỗ trợ động cơ đẩy khí lạnh và chao ăng-ten băng X/Ka.',
    },
    recommendedFor: 'Deep Space & Radar (SAR)',
  },
  {
    size: '12U',
    dimensions: '22.7 × 22.7 × 34 cm',
    maxMass: 24.0,
    payloadCapacity: '6.0 – 8.0 U',
    description: {
      en: 'Large-scale CubeSat carrying multi-instrument suites, electric ion thrusters, and high-cadence science operations (heritage: CAPSTONE).',
      vi: 'Khung CubeSat quy mô lớn mang cụm nhiều thiết bị đo, động cơ đẩy ion điện và bay quỹ đạo Mặt trăng (tiền lệ: CAPSTONE).',
    },
    recommendedFor: 'Lunar Orbiters & Flagship CubeSats',
  },
];

export const SizeSelect: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { design, updateDesign, nextScreen, prevScreen } = useGameStore();

  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 flex flex-col">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('size.title')}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {t('size.subtitle')}
          </p>
        </div>
        <div className="mt-4 md:mt-0 font-mono text-xs px-3.5 py-1.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 w-fit">
          Current Size:{' '}
          <span className="font-bold text-white">{design.size}</span>
        </div>
      </div>

      {/* Size Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-8">
        {SIZE_SPECS.map((spec) => {
          const isSelected = design.size === spec.size;

          return (
            <Card
              key={spec.size}
              selected={isSelected}
              onClick={() => updateDesign({ size: spec.size })}
              className="flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-slate-800 text-cyan-400">
                      <Box className="w-5 h-5" />
                    </div>
                    <span className="text-lg font-black font-mono text-slate-100">
                      {spec.size}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-cyan-400 font-semibold">
                    Max: {spec.maxMass} kg
                  </span>
                </div>

                <div className="text-xs font-mono text-slate-400 mb-2">
                  {spec.dimensions}
                </div>

                <p className="text-xs text-slate-300 leading-relaxed mb-4">
                  {spec.description[lang] || spec.description.en}
                </p>
              </div>

              <div className="border-t border-slate-800/80 pt-3 text-xs font-mono flex items-center justify-between text-slate-400">
                <span>Payload Cap:</span>
                <span className="text-slate-200 font-semibold">
                  {spec.payloadCapacity}
                </span>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={ArrowRight}
          iconPosition="right"
          onClick={nextScreen}
          className="shadow-lg shadow-cyan-500/25"
        >
          {t('nav.next')}
        </Button>
      </div>
    </div>
  );
};
