import React, { useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { CubeSatModel } from '../three/CubeSatModel';
import { createDefaultDesign } from '../../types/design';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import {
  Rocket,
  FolderOpen,
  Award,
  Sparkles,
  Trash2,
  Download,
  Upload,
} from 'lucide-react';
import {
  loadSavedDesigns,
  deleteSavedDesign,
  exportDesignAsJson,
  importDesignFromJson,
  saveDesignToStorage,
} from '../../store/saveManager';
import type { CubeSatDesign } from '../../types';

export const StartScreen: React.FC = () => {
  const { t } = useTranslation();
  const { setScreen, setDesign } = useGameStore();
  const [isSavedModalOpen, setIsSavedModalOpen] = useState(false);
  const [savedList, setSavedList] = useState<CubeSatDesign[]>([]);
  const previewDesign = createDefaultDesign();

  const handleOpenSaved = () => {
    setSavedList(loadSavedDesigns());
    setIsSavedModalOpen(true);
  };

  const handleSelectDesign = (design: CubeSatDesign) => {
    setDesign(design);
    setIsSavedModalOpen(false);
    setScreen('point-design');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteSavedDesign(id);
    setSavedList(loadSavedDesigns());
  };

  const handleExport = (design: CubeSatDesign, e: React.MouseEvent) => {
    e.stopPropagation();
    const jsonStr = exportDesignAsJson(design);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cubesat-${design.name || 'mission'}.json`;
    a.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        const imported = importDesignFromJson(text);
        if (imported) {
          saveDesignToStorage(imported);
          setSavedList(loadSavedDesigns());
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="relative w-full h-full min-h-[calc(100vh-65px)] flex flex-col items-center justify-between p-6 md:p-12 overflow-y-auto">
      {/* ── Background 3D Viewport ─────────────────────────────────── */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-80">
        <Canvas camera={{ position: [0, 0, 5], fov: 45 }}>
          <ambientLight intensity={0.4} />
          <directionalLight position={[10, 10, 5]} intensity={1.5} />
          <pointLight position={[-10, -5, -5]} color="#00d4ff" intensity={0.8} />
          <Stars radius={80} depth={40} count={3000} factor={4} saturation={0} fade />
          <CubeSatModel design={previewDesign} scale={1.2} />
          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.8} />
        </Canvas>
      </div>

      {/* ── Header Badge ───────────────────────────────────────────── */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-3xl pt-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-mono mb-4 backdrop-blur-md shadow-lg shadow-cyan-950/30">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>{t('app.nasaAppsChallenge')}</span>
        </div>

        <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-cyan-400 tracking-tight mb-3 drop-shadow-[0_4px_25px_rgba(0,212,255,0.3)]">
          {t('app.title')}
        </h1>

        <p className="text-base md:text-lg text-slate-300 max-w-xl font-normal leading-relaxed drop-shadow">
          {t('app.subtitle')}
        </p>
      </div>

      {/* ── Center Call To Action ──────────────────────────────────── */}
      <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4 my-8">
        <Button
          variant="primary"
          size="lg"
          icon={Rocket}
          onClick={() => setScreen('level-select')}
          className="w-56 text-base shadow-xl"
        >
          {t('nav.launch')}
        </Button>

        <Button
          variant="secondary"
          size="lg"
          icon={FolderOpen}
          onClick={handleOpenSaved}
          className="w-56 text-base"
        >
          {t('nav.load')}
        </Button>
      </div>

      {/* ── Feature Cards Footer ───────────────────────────────────── */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl w-full pb-4">
        <div className="glass-panel p-4 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-400 shrink-0">
            <Rocket className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-100">CubeSat 101 Standard</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Follow NASA CSLI flight standards from 1U to 12U bus architectures.
            </p>
          </div>
        </div>

        <div className="glass-panel p-4 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-100">CML 3/4 Point Design</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Multidisciplinary power, link, thermal, and mass budget closures.
            </p>
          </div>
        </div>

        <div className="glass-panel p-4 flex items-start gap-3">
          <div className="p-2 rounded-lg bg-teal-500/20 text-teal-400 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-100">NASA Mission Matching</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Cross-reference your satellite against real NASA deep space missions.
            </p>
          </div>
        </div>
      </div>

      {/* ── Saved Missions Modal ───────────────────────────────────── */}
      <Modal
        isOpen={isSavedModalOpen}
        onClose={() => setIsSavedModalOpen(false)}
        title={t('nav.load')}
      >
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-mono text-slate-400">
              {savedList.length} saved configuration(s)
            </span>
            <label className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-cyan-300 cursor-pointer transition-colors">
              <Upload className="w-3.5 h-3.5" />
              <span>{t('nav.import')}</span>
              <input
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleImport}
              />
            </label>
          </div>

          {savedList.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500">
              No saved missions yet. Complete a design to save your spacecraft!
            </div>
          ) : (
            <div className="flex flex-col gap-2.5 max-h-80 overflow-y-auto pr-1">
              {savedList.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleSelectDesign(item)}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/50 cursor-pointer transition-all"
                >
                  <div className="flex flex-col">
                    <span className="font-semibold text-slate-200 text-sm">
                      {item.name || 'Unnamed Mission'}
                    </span>
                    <span className="text-xs font-mono text-slate-400">
                      {item.size} • {item.orbit} •{' '}
                      {new Date(item.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => handleExport(item, e)}
                      className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-cyan-300"
                      title={t('nav.export')}
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => handleDelete(item.id, e)}
                      className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-rose-400"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};
