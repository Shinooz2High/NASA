import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { Button } from '../ui/Button';
import {
  ArrowLeft,
  ArrowRight,
  Zap,
  Radio,
  Thermometer,
  Flame,
  Compass,
} from 'lucide-react';
import type {
  PowerSubsystem,
  CommsSubsystem,
  ThermalSubsystem,
  PropulsionSubsystem,
  ADCSSubsystem,
} from '../../types';

type TabKey = 'power' | 'comms' | 'thermal' | 'propulsion' | 'adcs';

export const SubsystemDesign: React.FC = () => {
  const { t } = useTranslation();
  const { design, updateDesign, nextScreen, prevScreen } = useGameStore();
  const [activeTab, setActiveTab] = useState<TabKey>('power');

  // Subsystem update helpers
  const updatePower = (updates: Partial<PowerSubsystem>) => {
    updateDesign({ power: { ...design.power, ...updates } });
  };
  const updateComms = (updates: Partial<CommsSubsystem>) => {
    updateDesign({ comms: { ...design.comms, ...updates } });
  };
  const updateThermal = (updates: Partial<ThermalSubsystem>) => {
    updateDesign({ thermal: { ...design.thermal, ...updates } });
  };
  const updatePropulsion = (updates: Partial<PropulsionSubsystem>) => {
    updateDesign({ propulsion: { ...design.propulsion, ...updates } });
  };
  const updateAdcs = (updates: Partial<ADCSSubsystem>) => {
    updateDesign({ adcs: { ...design.adcs, ...updates } });
  };

  const tabs: Array<{ key: TabKey; label: string; icon: React.ElementType }> = [
    { key: 'power', label: t('subsystem.tabs.power'), icon: Zap },
    { key: 'comms', label: t('subsystem.tabs.comms'), icon: Radio },
    { key: 'thermal', label: t('subsystem.tabs.thermal'), icon: Thermometer },
    { key: 'propulsion', label: t('subsystem.tabs.propulsion'), icon: Flame },
    { key: 'adcs', label: t('subsystem.tabs.adcs'), icon: Compass },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 flex flex-col">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('subsystem.title')}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {t('subsystem.subtitle')}
          </p>
        </div>
      </div>

      {/* Tabs Header */}
      <div className="flex flex-wrap gap-2 p-1.5 rounded-xl bg-slate-900 border border-slate-800 mb-6">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs md:text-sm font-medium transition-all ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Panels */}
      <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 backdrop-blur-md shadow-xl min-h-[380px] mb-8">
        {/* ── POWER TAB ────────────────────────────────────────── */}
        {activeTab === 'power' && (
          <div className="space-y-6">
            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                {t('subsystem.solarPanel')}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'body-mounted', label: 'Body-Mounted Cells (Simple, Robust)' },
                  { id: 'deployable-fixed', label: 'Deployable Fixed Wings (3x Area)' },
                  { id: 'deployable-tracking', label: '1-Axis Sun-Tracking Wings (Max Power)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updatePower({ solarPanelType: item.id as any })}
                    className={`p-3.5 rounded-xl text-left border text-xs font-medium transition-all ${
                      design.power.solarPanelType === item.id
                        ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                {t('subsystem.solarCell')}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'silicon', label: 'Silicon (17% Eff, Low Cost)' },
                  { id: 'perovskite', label: 'Perovskite Tandem (22% Eff)' },
                  { id: 'triple-junction', label: 'Triple-Junction GaAs (30% Eff, Space Grade)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updatePower({ solarCellType: item.id as any })}
                    className={`p-3.5 rounded-xl text-left border text-xs font-medium transition-all ${
                      design.power.solarCellType === item.id
                        ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  {t('subsystem.batteryCapacity')}
                </label>
                <span className="text-xs font-mono font-bold text-cyan-400">
                  {design.power.batteryCapacity} Wh
                </span>
              </div>
              <input
                type="range"
                min="10"
                max="160"
                step="5"
                value={design.power.batteryCapacity}
                onChange={(e) =>
                  updatePower({ batteryCapacity: Number(e.target.value) })
                }
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
                <span>10 Wh (1U)</span>
                <span>40 Wh (3U standard)</span>
                <span>160 Wh (High Capacity)</span>
              </div>
            </div>
          </div>
        )}

        {/* ── COMMS TAB ────────────────────────────────────────── */}
        {activeTab === 'comms' && (
          <div className="space-y-6">
            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                {t('subsystem.frequency')}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { id: 'UHF', label: 'UHF (437 MHz, 9.6 kbps, Omnidirectional)' },
                  { id: 'S-band', label: 'S-band (2.2 GHz, 1 Mbps, Medium Rate)' },
                  { id: 'X-band', label: 'X-band (8.4 GHz, 10 Mbps, Science Downlink)' },
                  { id: 'Ka-band', label: 'Ka-band (26 GHz, 50+ Mbps, High Throughput)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updateComms({ frequency: item.id as any })}
                    className={`p-3.5 rounded-xl text-left border text-xs font-medium transition-all ${
                      design.comms.frequency === item.id
                        ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                {t('subsystem.antennaType')}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { id: 'dipole', label: 'Omni Tape Dipole' },
                  { id: 'patch', label: 'Patch Microstrip Array' },
                  { id: 'horn', label: 'Corrugated Horn' },
                  { id: 'parabolic', label: 'Deployable Parabolic Dish' },
                  { id: 'phased-array', label: 'Electronically Steered Array' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updateComms({ antennaType: item.id as any })}
                    className={`p-3.5 rounded-xl text-left border text-xs font-medium transition-all ${
                      design.comms.antennaType === item.id
                        ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  {t('subsystem.transmitPower')}
                </label>
                <span className="text-xs font-mono font-bold text-cyan-400">
                  {design.comms.transmitPower} W RF
                </span>
              </div>
              <input
                type="range"
                min="0.5"
                max="15"
                step="0.5"
                value={design.comms.transmitPower}
                onChange={(e) =>
                  updateComms({ transmitPower: Number(e.target.value) })
                }
                className="w-full accent-cyan-400 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
                <span>0.5 W (Beacon)</span>
                <span>2.0 W (Standard)</span>
                <span>15.0 W (High Power)</span>
              </div>
            </div>
          </div>
        )}

        {/* ── THERMAL TAB ──────────────────────────────────────── */}
        {activeTab === 'thermal' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <label className="flex items-center gap-3 p-4 rounded-xl bg-slate-950/40 border border-slate-800 cursor-pointer hover:border-slate-700">
                <input
                  type="checkbox"
                  checked={design.thermal.mli}
                  onChange={(e) => updateThermal({ mli: e.target.checked })}
                  className="w-4 h-4 accent-cyan-400 rounded"
                />
                <div>
                  <div className="text-xs font-bold text-slate-200">
                    {t('subsystem.mli')}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Kapton gold foil blanket to reject deep space cold & solar heat.
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-3 p-4 rounded-xl bg-slate-950/40 border border-slate-800 cursor-pointer hover:border-slate-700">
                <input
                  type="checkbox"
                  checked={design.thermal.heaters}
                  onChange={(e) => updateThermal({ heaters: e.target.checked })}
                  className="w-4 h-4 accent-cyan-400 rounded"
                />
                <div>
                  <div className="text-xs font-bold text-slate-200">
                    {t('subsystem.heaters')}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Electric survival patch heaters for batteries during long eclipses.
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-3 p-4 rounded-xl bg-slate-950/40 border border-slate-800 cursor-pointer hover:border-slate-700">
                <input
                  type="checkbox"
                  checked={design.thermal.radiators}
                  onChange={(e) => updateThermal({ radiators: e.target.checked })}
                  className="w-4 h-4 accent-cyan-400 rounded"
                />
                <div>
                  <div className="text-xs font-bold text-slate-200">
                    {t('subsystem.radiators')}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    High-emissivity silver teflon coatings to vent payload excess heat.
                  </div>
                </div>
              </label>
            </div>
          </div>
        )}

        {/* ── PROPULSION TAB ────────────────────────────────────── */}
        {activeTab === 'propulsion' && (
          <div className="space-y-6">
            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                {t('subsystem.propType')}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'none', label: 'None (Passive Drag Decay)' },
                  { id: 'cold-gas', label: 'Cold Gas (Isp 70s, Simple, Safe)' },
                  { id: 'resistojet', label: 'Electrically Heated Resistojet (Isp 150s)' },
                  { id: 'ion', label: 'Miniature Ion Gridded Thruster (Isp 3000s)' },
                  { id: 'hall-effect', label: 'Hall-Effect Plasma Thruster (Isp 1500s)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => updatePropulsion({ type: item.id as any })}
                    className={`p-3.5 rounded-xl text-left border text-xs font-medium transition-all ${
                      design.propulsion.type === item.id
                        ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {design.propulsion.type !== 'none' && (
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-mono uppercase tracking-wider text-slate-400">
                    {t('subsystem.propMass')}
                  </label>
                  <span className="text-xs font-mono font-bold text-cyan-400">
                    {design.propulsion.propellantMass} kg
                  </span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="3.0"
                  step="0.1"
                  value={design.propulsion.propellantMass}
                  onChange={(e) =>
                    updatePropulsion({ propellantMass: Number(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-slate-500 mt-1">
                  <span>0.1 kg</span>
                  <span>1.0 kg</span>
                  <span>3.0 kg</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── ADCS TAB ─────────────────────────────────────────── */}
        {activeTab === 'adcs' && (
          <div className="space-y-6">
            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                {t('subsystem.sensors')}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { id: 'sun-sensor', label: 'Coarse Sun Sensors' },
                  { id: 'magnetometer', label: '3-Axis Magnetometer' },
                  { id: 'star-tracker', label: 'High-Precision Star Tracker' },
                  { id: 'gyroscope', label: 'MEMS Rate Gyroscope' },
                ].map((sensor) => {
                  const isChecked = design.adcs.sensors.includes(sensor.id as any);
                  return (
                    <label
                      key={sensor.id}
                      className={`flex items-center gap-2 p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        isChecked
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                          : 'border-slate-800 bg-slate-950/40 text-slate-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => {
                          if (e.target.checked) {
                            updateAdcs({
                              sensors: [...design.adcs.sensors, sensor.id as any],
                            });
                          } else {
                            updateAdcs({
                              sensors: design.adcs.sensors.filter(
                                (s) => s !== sensor.id
                              ),
                            });
                          }
                        }}
                        className="accent-cyan-400"
                      />
                      <span>{sensor.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-2">
                {t('subsystem.actuators')}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { id: 'magnetorquer', label: 'Magnetic Torque Rods (Detumble & LEO)' },
                  { id: 'reaction-wheel', label: '3-Axis Reaction Wheels (Fine Pointing)' },
                  { id: 'momentum-wheel', label: 'Momentum Bias Wheel (High Stability)' },
                ].map((act) => {
                  const isChecked = design.adcs.actuators.includes(act.id as any);
                  return (
                    <label
                      key={act.id}
                      className={`flex items-center gap-2 p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        isChecked
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-200'
                          : 'border-slate-800 bg-slate-950/40 text-slate-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => {
                          if (e.target.checked) {
                            updateAdcs({
                              actuators: [...design.adcs.actuators, act.id as any],
                            });
                          } else {
                            updateAdcs({
                              actuators: design.adcs.actuators.filter(
                                (a) => a !== act.id
                              ),
                            });
                          }
                        }}
                        className="accent-cyan-400"
                      />
                      <span>{act.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={ArrowRight}
          iconPosition="right"
          onClick={nextScreen}
          className="shadow-lg shadow-cyan-500/25"
        >
          {t('nav.next')}
        </Button>
      </div>
    </div>
  );
};
