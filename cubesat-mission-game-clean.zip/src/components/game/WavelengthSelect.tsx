import React from 'react';
import { useTranslation } from 'react-i18next';
import { useGameStore } from '../../store/gameStore';
import { WAVELENGTHS } from '../../data/wavelengths';
import { getCompatibleWavelengths } from '../../data/compatibility';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import type { WavelengthBand } from '../../types';

export const WavelengthSelect: React.FC = () => {
  const { t, i18n } = useTranslation();
  const lang = i18n.language.startsWith('vi') ? 'vi' : 'en';
  const { level, design, updateDesign, nextScreen, prevScreen } = useGameStore();

  const maxSelectable = level === 1 ? 1 : level === 2 ? 2 : 3;
  const compatibleBands = getCompatibleWavelengths(design.objectives);
  const selectedBands = design.wavelengths;

  const handleToggle = (bandId: WavelengthBand) => {
    if (selectedBands.includes(bandId)) {
      updateDesign({
        wavelengths: selectedBands.filter((id) => id !== bandId),
      });
    } else {
      if (level === 1) {
        updateDesign({ wavelengths: [bandId] });
      } else if (selectedBands.length < maxSelectable) {
        updateDesign({ wavelengths: [...selectedBands, bandId] });
      }
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto py-8 px-4 flex flex-col">
      {/* Title & Counter */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {t('wavelengths.title')}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {t('wavelengths.subtitle')}
          </p>
        </div>
        <div className="mt-4 md:mt-0 font-mono text-xs px-3.5 py-1.5 rounded-full bg-slate-900 border border-cyan-500/30 text-cyan-300 w-fit">
          {t('wavelengths.selectLimit', { limit: maxSelectable })}:{' '}
          <span className="font-bold text-white">
            {selectedBands.length} / {maxSelectable}
          </span>
        </div>
      </div>

      {/* Spectrum Chart Bar */}
      <div className="mb-8 p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col gap-2">
        <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
          Electromagnetic Spectrum Continuity
        </span>
        <div className="h-4 w-full rounded-full overflow-hidden flex shadow-inner">
          {WAVELENGTHS.map((w) => (
            <div
              key={w.id}
              style={{ backgroundColor: w.color, width: `${100 / WAVELENGTHS.length}%` }}
              className="h-full opacity-80 hover:opacity-100 transition-opacity"
              title={`${w.name.en} (${w.range})`}
            />
          ))}
        </div>
        <div className="flex justify-between text-[10px] font-mono text-slate-500">
          <span>&gt; 1 mm (Radio)</span>
          <span>Visible (380-700 nm)</span>
          <span>&lt; 0.01 nm (Gamma)</span>
        </div>
      </div>

      {/* Wavelength Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {WAVELENGTHS.map((wave) => {
          const isCompatible = compatibleBands.includes(wave.id);
          const isSelected = selectedBands.includes(wave.id);
          const isDisabled =
            !isCompatible ||
            (!isSelected && selectedBands.length >= maxSelectable && level !== 1);

          return (
            <Card
              key={wave.id}
              selected={isSelected}
              disabled={isDisabled}
              onClick={() => handleToggle(wave.id)}
              className="flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-3.5 h-3.5 rounded-full shadow-sm"
                      style={{ backgroundColor: wave.color }}
                    />
                    <h3 className="text-base font-bold text-slate-100">
                      {wave.name[lang] || wave.name.en}
                    </h3>
                  </div>
                  {isCompatible ? (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-400 border border-emerald-800/40">
                      Target Match
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-500">
                      Incompatible
                    </span>
                  )}
                </div>

                <div className="text-xs font-mono text-cyan-400 mb-2">
                  {wave.range}
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {wave.description[lang] || wave.description.en}
                </p>
              </div>

              <div className="border-t border-slate-800/80 pt-3">
                <span className="text-[11px] text-slate-500 font-mono block mb-1">
                  {t('wavelengths.compatibleInst')}:
                </span>
                <div className="flex flex-wrap gap-1">
                  {wave.compatibleInstruments.map((instId) => (
                    <span
                      key={instId}
                      className="px-1.5 py-0.5 rounded bg-slate-800/90 text-slate-300 text-[10px] font-mono"
                    >
                      {instId.replace('-', ' ')}
                    </span>
                  ))}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-4 border-t border-slate-800">
        <Button variant="ghost" icon={ArrowLeft} onClick={prevScreen}>
          {t('nav.back')}
        </Button>
        <Button
          variant="primary"
          icon={ArrowRight}
          iconPosition="right"
          disabled={selectedBands.length === 0}
          onClick={nextScreen}
          className="shadow-lg shadow-cyan-500/25"
        >
          {t('nav.next')}
        </Button>
      </div>
    </div>
  );
};
