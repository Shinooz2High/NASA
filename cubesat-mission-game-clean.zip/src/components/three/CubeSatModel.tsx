import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import type { CubeSatDesign } from '../../types';
import { sizeToUnits } from '../../data/compatibility';

interface CubeSatModelProps {
  design: CubeSatDesign;
  interactive?: boolean;
  scale?: number;
}

export const CubeSatModel: React.FC<CubeSatModelProps> = ({
  design,
  scale = 1.0,
}) => {
  const groupRef = useRef<THREE.Group>(null);
  const units = sizeToUnits(design.size);

  // Auto slow rotation
  useFrame((_, delta) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += delta * 0.4;
      groupRef.current.rotation.x = Math.sin(Date.now() * 0.001) * 0.15;
    }
  });

  // Dimensions based on standard CubeSat geometry (1U = 10 x 10 x 10 cm)
  // Let 1U = 1.0 in 3D scene units
  let width = 1.0;
  let depth = 1.0;
  let height = units * 1.0;

  if (design.size === '6U') {
    width = 1.0;
    depth = 2.0;
    height = 3.0;
  } else if (design.size === '12U') {
    width = 2.0;
    depth = 2.0;
    height = 3.0;
  }

  // Solar panel wing size
  const wingWidth = 0.9;
  const wingHeight = height * 0.9;

  return (
    <group ref={groupRef} scale={[scale, scale, scale]}>
      {/* ── Main Chassis Body ───────────────────────────────────── */}
      <mesh castShadow receiveShadow>
        <boxGeometry args={[width, height, depth]} />
        <meshStandardMaterial
          color={design.thermal.mli ? '#d4af37' : '#1e293b'} // Gold MLI foil or dark anodized aluminum
          metalness={0.85}
          roughness={0.25}
        />
      </mesh>

      {/* ── Chassis Corner Aluminum Rails (CubeSat Spec) ───────── */}
      <lineSegments>
        <edgesGeometry args={[new THREE.BoxGeometry(width * 1.01, height * 1.01, depth * 1.01)]} />
        <lineBasicMaterial color="#38bdf8" linewidth={2} />
      </lineSegments>

      {/* ── Body-mounted Solar Cells (dark blue with gold traces) ── */}
      {design.power.solarPanelType === 'body-mounted' && (
        <group>
          {/* Front Face Solar Cells */}
          <mesh position={[0, 0, depth / 2 + 0.01]}>
            <planeGeometry args={[width * 0.85, height * 0.85]} />
            <meshStandardMaterial
              color="#0f172a"
              emissive="#1e3a8a"
              emissiveIntensity={0.2}
              metalness={0.9}
              roughness={0.1}
            />
          </mesh>
          {/* Back Face Solar Cells */}
          <mesh position={[0, 0, -depth / 2 - 0.01]} rotation={[0, Math.PI, 0]}>
            <planeGeometry args={[width * 0.85, height * 0.85]} />
            <meshStandardMaterial
              color="#0f172a"
              emissive="#1e3a8a"
              emissiveIntensity={0.2}
              metalness={0.9}
              roughness={0.1}
            />
          </mesh>
        </group>
      )}

      {/* ── Deployable Solar Array Wings ─────────────────────────── */}
      {(design.power.solarPanelType === 'deployable-fixed' ||
        design.power.solarPanelType === 'deployable-tracking') && (
        <group>
          {/* Left Wing */}
          <group position={[-width / 2, 0, 0]}>
            <mesh position={[-wingWidth / 2, 0, 0]} castShadow>
              <boxGeometry args={[wingWidth, wingHeight, 0.04]} />
              <meshStandardMaterial
                color="#09142b"
                emissive="#0284c7"
                emissiveIntensity={0.25}
                metalness={0.9}
                roughness={0.15}
              />
            </mesh>
            {/* Wing Hinge */}
            <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.04, 0.04, wingHeight * 0.8, 8]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.9} />
            </mesh>
          </group>

          {/* Right Wing */}
          <group position={[width / 2, 0, 0]}>
            <mesh position={[wingWidth / 2, 0, 0]} castShadow>
              <boxGeometry args={[wingWidth, wingHeight, 0.04]} />
              <meshStandardMaterial
                color="#09142b"
                emissive="#0284c7"
                emissiveIntensity={0.25}
                metalness={0.9}
                roughness={0.15}
              />
            </mesh>
            {/* Wing Hinge */}
            <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.04, 0.04, wingHeight * 0.8, 8]} />
              <meshStandardMaterial color="#94a3b8" metalness={0.9} />
            </mesh>
          </group>
        </group>
      )}

      {/* ── Optical Payload Aperture / Telescope Lens ────────────── */}
      <group position={[0, height / 2 + 0.02, 0]}>
        {/* Lens Barrel */}
        <mesh position={[0, 0.08, 0]}>
          <cylinderGeometry args={[0.28, 0.32, 0.16, 24]} />
          <meshStandardMaterial color="#0f172a" metalness={0.9} roughness={0.2} />
        </mesh>
        {/* Optical Glass Lens */}
        <mesh position={[0, 0.16, 0]}>
          <cylinderGeometry args={[0.26, 0.26, 0.02, 24]} />
          <meshPhysicalMaterial
            color="#38bdf8"
            transmission={0.8}
            opacity={0.9}
            transparent
            roughness={0.05}
            ior={1.5}
          />
        </mesh>
      </group>

      {/* ── Communications Antennas ──────────────────────────────── */}
      {design.comms.frequency === 'UHF' ? (
        // UHF Deployable Tape-Spring Dipole Antennas (4 crossing elements)
        <group position={[0, -height / 2, 0]}>
          <mesh position={[0.5, -0.4, 0]} rotation={[0, 0, -Math.PI / 4]}>
            <cylinderGeometry args={[0.015, 0.015, 1.2, 6]} />
            <meshStandardMaterial color="#e2e8f0" metalness={0.9} />
          </mesh>
          <mesh position={[-0.5, -0.4, 0]} rotation={[0, 0, Math.PI / 4]}>
            <cylinderGeometry args={[0.015, 0.015, 1.2, 6]} />
            <meshStandardMaterial color="#e2e8f0" metalness={0.9} />
          </mesh>
        </group>
      ) : design.comms.frequency === 'Ka-band' ||
        design.comms.antennaType === 'parabolic' ? (
        // High-Gain Parabolic Dish or Phased Array
        <group position={[0, 0, depth / 2 + 0.15]} rotation={[Math.PI / 4, 0, 0]}>
          <mesh>
            <sphereGeometry args={[0.4, 24, 12, 0, Math.PI * 2, 0, Math.PI / 3]} />
            <meshStandardMaterial
              color="#e2e8f0"
              metalness={0.9}
              roughness={0.2}
              side={THREE.DoubleSide}
            />
          </mesh>
          {/* Feed horn */}
          <mesh position={[0, 0.22, 0]}>
            <cylinderGeometry args={[0.03, 0.01, 0.2, 8]} />
            <meshStandardMaterial color="#0284c7" metalness={0.8} />
          </mesh>
        </group>
      ) : (
        // S-band / X-band Patch Antenna
        <mesh position={[0, 0, depth / 2 + 0.02]}>
          <boxGeometry args={[0.35, 0.35, 0.03]} />
          <meshStandardMaterial color="#eab308" metalness={0.8} roughness={0.3} />
        </mesh>
      )}

      {/* ── Propulsion Thruster Nozzle ───────────────────────────── */}
      {design.propulsion.type !== 'none' && (
        <group position={[0, -height / 2 - 0.08, 0]} rotation={[Math.PI, 0, 0]}>
          <mesh>
            <coneGeometry args={[0.18, 0.2, 16, 1, true]} />
            <meshStandardMaterial
              color="#334155"
              metalness={0.9}
              roughness={0.3}
              side={THREE.DoubleSide}
            />
          </mesh>
          {/* Thruster Glow / Core */}
          <mesh position={[0, 0.05, 0]}>
            <sphereGeometry args={[0.06, 8, 8]} />
            <meshBasicMaterial
              color={design.propulsion.type === 'ion' ? '#38bdf8' : '#fb923c'}
            />
          </mesh>
        </group>
      )}

      {/* ── Status Beacon LED ───────────────────────────────────── */}
      <mesh position={[width / 2 - 0.1, height / 2 - 0.1, depth / 2 + 0.02]}>
        <sphereGeometry args={[0.035, 8, 8]} />
        <meshBasicMaterial color="#00ff88" />
      </mesh>
    </group>
  );
};
