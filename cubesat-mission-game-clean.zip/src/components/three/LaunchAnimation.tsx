import React, { useEffect, useRef, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';
import { useTranslation } from 'react-i18next';
import { CubeSatModel } from './CubeSatModel';
import type { CubeSatDesign } from '../../types';
import { Button } from '../ui/Button';
import { FastForward, CheckCircle2 } from 'lucide-react';

interface LaunchAnimationProps {
  design: CubeSatDesign;
  onComplete: () => void;
}

type LaunchStage =
  | 'countdown'
  | 'ignition'
  | 'ascent'
  | 'stage-sep'
  | 'orbital-insertion'
  | 'deployment'
  | 'complete';

// ── 3D Scene Components for Launch ──────────────────────────────────────────

const RocketAndExhaust: React.FC<{
  altitude: number;
  exhaustVisible: boolean;
}> = ({ altitude, exhaustVisible }) => {
  const flameRef = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (flameRef.current) {
      flameRef.current.scale.y = 0.9 + Math.random() * 0.3;
    }
  });

  return (
    <group position={[0, altitude, 0]}>
      {/* Rocket Upper Stage Body */}
      <mesh position={[0, 2, 0]}>
        <cylinderGeometry args={[0.7, 0.7, 5, 32]} />
        <meshStandardMaterial color="#f8fafc" metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Fairing Nose Cone */}
      <mesh position={[0, 5.2, 0]}>
        <coneGeometry args={[0.7, 1.6, 32]} />
        <meshStandardMaterial color="#f8fafc" metalness={0.6} roughness={0.3} />
      </mesh>

      {/* Engine Bell */}
      <mesh position={[0, -0.7, 0]} rotation={[Math.PI, 0, 0]}>
        <coneGeometry args={[0.5, 0.8, 16, 1, true]} />
        <meshStandardMaterial color="#334155" metalness={0.9} side={THREE.DoubleSide} />
      </mesh>

      {/* Thruster Plume Flame */}
      {exhaustVisible && (
        <group position={[0, -1.8, 0]}>
          <mesh ref={flameRef} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.6, 2.5, 16]} />
            <meshBasicMaterial color="#fb923c" transparent opacity={0.85} />
          </mesh>
          <pointLight color="#f97316" intensity={4} distance={15} />
        </group>
      )}
    </group>
  );
};

const DeploymentScene: React.FC<{
  design: CubeSatDesign;
  cubeSatDistance: number;
}> = ({ design, cubeSatDistance }) => {
  return (
    <group>
      {/* P-POD Dispenser Shell */}
      <mesh position={[0, 0, -2.5]}>
        <boxGeometry args={[1.5, 3.8, 1.5]} />
        <meshStandardMaterial color="#334155" metalness={0.8} roughness={0.3} />
      </mesh>

      {/* Ejected CubeSat floating outwards */}
      <group position={[0, 0, cubeSatDistance]}>
        <CubeSatModel design={design} scale={0.9} />
      </group>
    </group>
  );
};

// ── Main Launch Sequence Component ──────────────────────────────────────────

export const LaunchAnimation: React.FC<LaunchAnimationProps> = ({
  design,
  onComplete,
}) => {
  const { t } = useTranslation();
  const [stage, setStage] = useState<LaunchStage>('countdown');
  const [countdown, setCountdown] = useState(5);
  const [rocketAlt, setRocketAlt] = useState(-5);
  const [deployDist, setDeployDist] = useState(0);

  // Timeline progression
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;

    if (stage === 'countdown') {
      interval = setInterval(() => {
        setCountdown((c) => {
          if (c <= 1) {
            setStage('ignition');
            return 0;
          }
          return c - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [stage]);

  // Stage transition timeouts
  useEffect(() => {
    if (stage === 'ignition') {
      const timer = setTimeout(() => setStage('ascent'), 1200);
      return () => clearTimeout(timer);
    }
    if (stage === 'ascent') {
      const timer = setTimeout(() => setStage('stage-sep'), 3500);
      return () => clearTimeout(timer);
    }
    if (stage === 'stage-sep') {
      const timer = setTimeout(() => setStage('orbital-insertion'), 2000);
      return () => clearTimeout(timer);
    }
    if (stage === 'orbital-insertion') {
      const timer = setTimeout(() => setStage('deployment'), 2500);
      return () => clearTimeout(timer);
    }
    if (stage === 'deployment') {
      const timer = setTimeout(() => setStage('complete'), 3500);
      return () => clearTimeout(timer);
    }
    if (stage === 'complete') {
      const timer = setTimeout(() => onComplete(), 1500);
      return () => clearTimeout(timer);
    }
  }, [stage, onComplete]);

  // Smooth altitude & distance animation
  useEffect(() => {
    let animFrame: number;
    const animate = () => {
      if (stage === 'ascent') {
        setRocketAlt((a) => a + 0.12);
      } else if (stage === 'deployment' || stage === 'complete') {
        setDeployDist((d) => Math.min(2.5, d + 0.04));
      }
      animFrame = requestAnimationFrame(animate);
    };
    animFrame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animFrame);
  }, [stage]);

  // Get current status readout
  const getStatusText = () => {
    switch (stage) {
      case 'countdown':
        return t('launch.status.prep');
      case 'ignition':
        return t('launch.status.ignition');
      case 'ascent':
        return t('launch.status.ascent');
      case 'stage-sep':
        return t('launch.status.stage');
      case 'orbital-insertion':
        return t('launch.status.insertion');
      case 'deployment':
        return t('launch.status.deploy');
      case 'complete':
        return t('launch.status.telemetry');
    }
  };

  return (
    <div className="relative w-full h-[calc(100vh-120px)] bg-slate-950 overflow-hidden flex flex-col items-center justify-center">
      {/* ── 3D Canvas ────────────────────────────────────────────── */}
      <div className="absolute inset-0">
        <Canvas camera={{ position: [0, 0, 7], fov: 45 }}>
          <ambientLight intensity={0.4} />
          <directionalLight position={[10, 10, 5]} intensity={1.5} castShadow />
          <Stars radius={100} depth={50} count={3500} factor={4} saturation={0} fade />

          {stage === 'deployment' || stage === 'complete' ? (
            <DeploymentScene design={design} cubeSatDistance={deployDist} />
          ) : (
            <RocketAndExhaust
              altitude={rocketAlt}
              exhaustVisible={stage === 'ascent' || stage === 'ignition'}
            />
          )}

          <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.5} />
        </Canvas>
      </div>

      {/* ── Overlay HUD ─────────────────────────────────────────── */}
      <div className="relative z-10 w-full max-w-2xl px-6 pointer-events-none flex flex-col items-center">
        {/* Countdown Large Display */}
        {stage === 'countdown' && (
          <div className="mb-8 flex flex-col items-center animate-bounce">
            <span className="text-sm font-mono uppercase tracking-widest text-cyan-400">
              {t('launch.title')}
            </span>
            <div className="text-8xl font-black font-mono text-white tracking-tighter drop-shadow-[0_0_35px_rgba(6,182,212,0.6)]">
              T-{countdown}
            </div>
          </div>
        )}

        {/* Telemetry Status Console Box */}
        <div className="w-full bg-slate-900/80 border border-cyan-500/40 rounded-xl p-5 backdrop-blur-md shadow-2xl flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-green-400 animate-ping" />
              <span className="text-xs font-mono font-bold tracking-wider text-cyan-300 uppercase">
                MISSION FLIGHT TELEMETRY
              </span>
            </div>
            <span className="text-xs font-mono text-slate-400 uppercase">
              PHASE: {stage}
            </span>
          </div>

          <div className="text-sm md:text-base font-mono text-slate-200 min-h-[48px] flex items-center">
            {getStatusText()}
          </div>

          {/* Subsystem telemetry checklist */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800/80 text-xs font-mono">
            <div className="flex items-center gap-1.5 text-slate-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>OBC: NOMINAL</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>BUS: {design.size}</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>ORBIT: {design.orbit}</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>RF: {design.comms.frequency}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── Skip Button ─────────────────────────────────────────── */}
      <div className="absolute bottom-6 right-6 z-20">
        <Button
          variant="secondary"
          size="sm"
          icon={FastForward}
          onClick={onComplete}
        >
          {t('launch.skip')}
        </Button>
      </div>
    </div>
  );
};
