import React, { useMemo, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stars } from '@react-three/drei';
import * as THREE from 'three';
import type { CubeSatDesign, OrbitParameters } from '../../types';
import { ORBITS } from '../../data/orbits';
import { CubeSatModel } from './CubeSatModel';

interface OrbitSceneProps {
  design: CubeSatDesign;
  className?: string;
}

// ── 3D Earth & Atmosphere ───────────────────────────────────────────────────

const EarthGlobe: React.FC = () => {
  const earthRef = useRef<THREE.Mesh>(null);
  const cloudsRef = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (earthRef.current) earthRef.current.rotation.y += delta * 0.05;
    if (cloudsRef.current) cloudsRef.current.rotation.y += delta * 0.07;
  });

  return (
    <group>
      {/* Earth Surface Sphere */}
      <mesh ref={earthRef}>
        <sphereGeometry args={[2.0, 64, 64]} />
        <meshStandardMaterial
          color="#1e3a8a" // Deep ocean blue
          roughness={0.6}
          metalness={0.1}
        />
      </mesh>

      {/* Atmospheric Glow Shell */}
      <mesh>
        <sphereGeometry args={[2.08, 32, 32]} />
        <meshStandardMaterial
          color="#38bdf8"
          transparent
          opacity={0.15}
          side={THREE.BackSide}
        />
      </mesh>
    </group>
  );
};

// ── Orbit Trajectory Line & Orbiting Satellite ──────────────────────────────

const OrbitPathAndSatellite: React.FC<{
  orbit: OrbitParameters;
  design: CubeSatDesign;
}> = ({ orbit, design }) => {
  const satRef = useRef<THREE.Group>(null);

  // Scaled orbital radius for 3D visualization
  let orbitRadius = 2.8; // LEO default
  if (orbit.type === 'SSO') orbitRadius = 2.9;
  if (orbit.type === 'MEO') orbitRadius = 3.6;
  if (orbit.type === 'GEO') orbitRadius = 5.2;
  if (orbit.type === 'HEO') orbitRadius = 4.8;
  if (orbit.type === 'lunar') orbitRadius = 6.2;
  if (orbit.type === 'L1' || orbit.type === 'L2' || orbit.type === 'interplanetary') {
    orbitRadius = 7.0;
  }

  // Generate orbit ring points
  const lineObject = useMemo(() => {
    const points: THREE.Vector3[] = [];
    const segments = 128;
    for (let i = 0; i <= segments; i++) {
      const theta = (i / segments) * Math.PI * 2;
      const inclRad = (orbit.inclination * Math.PI) / 180;
      const x = Math.cos(theta) * orbitRadius;
      const y = Math.sin(theta) * orbitRadius * Math.sin(inclRad);
      const z = Math.sin(theta) * orbitRadius * Math.cos(inclRad);
      points.push(new THREE.Vector3(x, y, z));
    }
    const geom = new THREE.BufferGeometry().setFromPoints(points);
    const mat = new THREE.LineBasicMaterial({
      color: '#00d4ff',
      transparent: true,
      opacity: 0.65,
    });
    return new THREE.Line(geom, mat);
  }, [orbit.inclination, orbitRadius]);

  // Animate CubeSat along the trajectory
  useFrame(({ clock }) => {
    if (satRef.current) {
      const t = clock.getElapsedTime() * 0.4;
      const inclRad = (orbit.inclination * Math.PI) / 180;
      const x = Math.cos(t) * orbitRadius;
      const y = Math.sin(t) * orbitRadius * Math.sin(inclRad);
      const z = Math.sin(t) * orbitRadius * Math.cos(inclRad);
      satRef.current.position.set(x, y, z);
      satRef.current.lookAt(0, 0, 0); // Nadir pointing (towards Earth center)
    }
  });

  return (
    <group>
      {/* Orbit Track Line */}
      <primitive object={lineObject} />

      {/* Orbiting Spacecraft */}
      <group ref={satRef}>
        <CubeSatModel design={design} scale={0.25} />
        {/* Footprint sensor cone beam directed at Earth */}
        <mesh position={[0, 0, 0.6]} rotation={[Math.PI / 2, 0, 0]}>
          <coneGeometry args={[0.3, 1.2, 16, 1, true]} />
          <meshBasicMaterial color="#00ff88" transparent opacity={0.2} side={THREE.DoubleSide} />
        </mesh>
      </group>
    </group>
  );
};

// ── Main OrbitScene Canvas ──────────────────────────────────────────────────

export const OrbitScene: React.FC<OrbitSceneProps> = ({
  design,
  className = 'w-full h-80 rounded-xl overflow-hidden',
}) => {
  const orbit =
    ORBITS.find((o) => o.type === design.orbit) ||
    ORBITS[0];

  return (
    <div className={`relative ${className} bg-slate-950/80 border border-slate-800`}>
      <Canvas camera={{ position: [0, 4, 7], fov: 45 }}>
        <ambientLight intensity={0.3} />
        <directionalLight position={[10, 5, 8]} intensity={1.8} castShadow />
        <Stars radius={80} depth={40} count={2000} factor={3} saturation={0} fade />

        <EarthGlobe />
        <OrbitPathAndSatellite orbit={orbit} design={design} />

        <OrbitControls
          enableZoom={true}
          minDistance={3.5}
          maxDistance={14}
          autoRotate={false}
        />
      </Canvas>

      {/* Mini Orbit HUD badge */}
      <div className="absolute bottom-3 left-3 px-3 py-1.5 rounded-lg bg-slate-900/80 border border-cyan-500/30 backdrop-blur-md text-[11px] font-mono text-cyan-300">
        <span className="text-slate-400">Orbit:</span> {orbit.name.en} | Alt: {orbit.altitude} km
      </div>
    </div>
  );
};
