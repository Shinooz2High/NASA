import React from 'react';

interface CardProps {
  selected?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  className?: string;
  children: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({
  selected = false,
  disabled = false,
  onClick,
  className = '',
  children,
}) => {
  return (
    <div
      onClick={!disabled ? onClick : undefined}
      className={`relative rounded-xl p-5 transition-all duration-200 select-none ${
        onClick && !disabled ? 'cursor-pointer hover:translate-y-[-2px]' : ''
      } ${
        disabled
          ? 'opacity-40 cursor-not-allowed bg-slate-900/40 border border-slate-800'
          : selected
          ? 'bg-slate-900/90 border-2 border-cyan-400 shadow-xl shadow-cyan-500/20 ring-1 ring-cyan-400/50'
          : 'bg-slate-900/60 hover:bg-slate-900/80 border border-slate-700/60 hover:border-slate-500/80 backdrop-blur-md shadow-md'
      } ${className}`}
    >
      {selected && (
        <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-cyan-400 text-slate-950 flex items-center justify-center text-xs font-bold shadow-sm">
          ✓
        </div>
      )}
      {children}
    </div>
  );
};
