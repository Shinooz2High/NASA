import React from 'react';
import { useTranslation } from 'react-i18next';
import { Globe } from 'lucide-react';

export const LanguageToggle: React.FC = () => {
  const { i18n } = useTranslation();
  const currentLang = i18n.language.startsWith('vi') ? 'vi' : 'en';

  const toggleLanguage = () => {
    const nextLang = currentLang === 'en' ? 'vi' : 'en';
    i18n.changeLanguage(nextLang);
  };

  return (
    <button
      onClick={toggleLanguage}
      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-cyan-300 border border-cyan-500/30 hover:border-cyan-400 text-xs font-mono font-medium transition-all shadow-sm select-none"
      title={currentLang === 'en' ? 'Chuyển sang Tiếng Việt' : 'Switch to English'}
    >
      <Globe className="w-3.5 h-3.5 text-cyan-400" />
      <span className="font-semibold uppercase">{currentLang}</span>
      <span className="text-slate-500">|</span>
      <span className="text-slate-400">
        {currentLang === 'en' ? 'VI' : 'EN'}
      </span>
    </button>
  );
};
