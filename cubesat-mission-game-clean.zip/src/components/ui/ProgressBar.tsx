import React from 'react';
import type { GameScreen } from '../../types';

interface ProgressBarProps {
  currentScreen: GameScreen;
  level: number;
}

const ALL_STEPS: Array<{ id: GameScreen; labelEn: string; labelVi: string }> = [
  { id: 'level-select', labelEn: 'Level', labelVi: 'Cấp độ' },
  { id: 'objective-select', labelEn: 'Goals', labelVi: 'Mục tiêu' },
  { id: 'wavelength-select', labelEn: 'Spectrum', labelVi: 'Quang phổ' },
  { id: 'instrument-select', labelEn: 'Payload', labelVi: 'Thiết bị' },
  { id: 'optics-select', labelEn: 'Optics', labelVi: 'Quang học' },
  { id: 'size-select', labelEn: 'Bus Size', labelVi: 'Kích cỡ' },
  { id: 'orbit-select', labelEn: 'Orbit', labelVi: 'Quỹ đạo' },
  { id: 'subsystem-design', labelEn: 'Subsystems', labelVi: 'Phân hệ' },
  { id: 'point-design', labelEn: 'Point Design', labelVi: 'Đánh giá' },
  { id: 'launch', labelEn: 'Launch', labelVi: 'Phóng' },
  { id: 'results', labelEn: 'Results', labelVi: 'Kết quả' },
  { id: 'nasa-match', labelEn: 'NASA Analogue', labelVi: 'Đối chiếu' },
];

export const ProgressBar: React.FC<ProgressBarProps> = ({
  currentScreen,
  level,
}) => {
  // If in start screen, don't show steps
  if (currentScreen === 'start') return null;

  // Filter out skipped steps in level 1
  const steps = ALL_STEPS.filter((step) => {
    if (level === 1) {
      if (
        step.id === 'optics-select' ||
        step.id === 'size-select' ||
        step.id === 'subsystem-design'
      ) {
        return false;
      }
    }
    return true;
  });

  const currentIndex = steps.findIndex((s) => s.id === currentScreen);
  const progressPercent = Math.max(
    5,
    Math.round(((currentIndex + 1) / steps.length) * 100)
  );

  return (
    <div className="w-full bg-slate-950/80 border-b border-cyan-500/20 backdrop-blur-md px-4 py-2.5 z-40">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-1.5 text-xs">
          <span className="text-cyan-400 font-mono tracking-wider uppercase">
            Phase: {currentScreen.replace('-', ' ')}
          </span>
          <span className="text-slate-400 font-mono">
            Step {Math.max(1, currentIndex + 1)} of {steps.length} ({progressPercent}%)
          </span>
        </div>

        {/* Progress track */}
        <div className="relative w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-green-400 rounded-full transition-all duration-300 shadow-sm shadow-cyan-400/50"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Micro step indicators */}
        <div className="hidden md:flex justify-between mt-2">
          {steps.map((step, idx) => {
            const isCompleted = idx < currentIndex;
            const isCurrent = idx === currentIndex;
            return (
              <div
                key={step.id}
                className="flex flex-col items-center group cursor-default"
                style={{ width: `${100 / steps.length}%` }}
              >
                <div
                  className={`w-2 h-2 rounded-full mb-1 transition-all ${
                    isCurrent
                      ? 'bg-cyan-400 ring-4 ring-cyan-400/20 scale-125'
                      : isCompleted
                      ? 'bg-green-400'
                      : 'bg-slate-700'
                  }`}
                />
                <span
                  className={`text-[10px] truncate max-w-[80px] text-center ${
                    isCurrent
                      ? 'text-cyan-300 font-semibold'
                      : isCompleted
                      ? 'text-slate-400'
                      : 'text-slate-600'
                  }`}
                >
                  {step.labelEn}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
