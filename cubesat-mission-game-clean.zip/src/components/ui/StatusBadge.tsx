import React from 'react';

interface StatusBadgeProps {
  status: 'ok' | 'warning' | 'critical';
  label?: string;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  label,
  size = 'md',
}) => {
  const styles = {
    ok: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
    warning: 'bg-amber-500/15 text-amber-300 border-amber-500/40',
    critical: 'bg-rose-500/15 text-rose-300 border-rose-500/40',
  }[status];

  const dotColors = {
    ok: 'bg-emerald-400 shadow-emerald-400/50',
    warning: 'bg-amber-400 shadow-amber-400/50',
    critical: 'bg-rose-400 shadow-rose-400/50',
  }[status];

  const defaultLabels = {
    ok: 'NOMINAL',
    warning: 'MARGINAL',
    critical: 'CRITICAL',
  }[status];

  const sizeStyles = {
    sm: 'text-[10px] px-2 py-0.5 gap-1.5',
    md: 'text-xs px-2.5 py-1 gap-2',
  }[size];

  return (
    <span
      className={`inline-flex items-center font-mono font-semibold rounded-full border ${styles} ${sizeStyles}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${dotColors} shadow-sm animate-pulse`} />
      <span>{label || defaultLabels}</span>
    </span>
  );
};
