// ============================================================================
// CubeSat Mission Designer — Compatibility Helper Functions
// ============================================================================

import type {
  CubeSatSize,
  Instrument,
  OpticalSystem,
  OrbitParameters,
  WavelengthBand,
} from '../types/mission';
import { OBJECTIVES } from './objectives';
import { WAVELENGTHS } from './wavelengths';
import { INSTRUMENTS } from './instruments';
import { OPTICS } from './optics';
import { ORBITS } from './orbits';

/**
 * Convert CubeSat size string to numerical units (1U = 1, 2U = 2, 3U = 3, etc.)
 */
export function sizeToUnits(size: CubeSatSize): number {
  switch (size) {
    case '1U':
      return 1;
    case '2U':
      return 2;
    case '3U':
      return 3;
    case '6U':
      return 6;
    case '12U':
      return 12;
    default:
      return 3;
  }
}

/**
 * Returns available wavelengths compatible with ANY of the selected objectives.
 * If multiple objectives are selected, an objective may be fulfilled if at least one of its wavelengths is selected.
 */
export function getCompatibleWavelengths(objectiveIds: string[]): WavelengthBand[] {
  if (objectiveIds.length === 0) {
    return WAVELENGTHS.map((w) => w.id);
  }

  const selectedObjs = OBJECTIVES.filter((obj) => objectiveIds.includes(obj.id));
  const compatibleSet = new Set<WavelengthBand>();

  selectedObjs.forEach((obj) => {
    obj.compatibleWavelengths.forEach((w) => compatibleSet.add(w));
  });

  return Array.from(compatibleSet);
}

/**
 * Returns instruments matching selected wavelengths and CubeSat size envelope.
 */
export function getCompatibleInstruments(
  wavelengths: WavelengthBand[],
  size: CubeSatSize = '3U'
): Instrument[] {
  const currentUnits = sizeToUnits(size);

  return INSTRUMENTS.filter((inst) => {
    // Check if instrument has at least one matching wavelength band
    const hasWavelength =
      wavelengths.length === 0 ||
      inst.compatibleWavelengths.some((w) => wavelengths.includes(w));

    // Check size constraint
    const fitsSize = currentUnits >= sizeToUnits(inst.minSize);

    return hasWavelength && fitsSize;
  });
}

/**
 * Returns optical/antenna systems compatible with selected wavelengths and CubeSat size.
 */
export function getCompatibleOptics(
  wavelengths: WavelengthBand[],
  size: CubeSatSize = '3U'
): OpticalSystem[] {
  const currentUnits = sizeToUnits(size);

  return OPTICS.filter((opt) => {
    const hasWavelength =
      wavelengths.length === 0 ||
      opt.compatibleWavelengths.some((w) => wavelengths.includes(w));
    const fitsSize = currentUnits >= sizeToUnits(opt.minSize);
    return hasWavelength && fitsSize;
  });
}

/**
 * Returns suggested and compatible orbits for selected objectives.
 */
export function getCompatibleOrbits(objectiveIds: string[]): OrbitParameters[] {
  if (objectiveIds.length === 0) {
    return ORBITS;
  }

  const selectedObjs = OBJECTIVES.filter((obj) => objectiveIds.includes(obj.id));
  const suggestedOrbitTypes = new Set<string>();

  selectedObjs.forEach((obj) => {
    obj.suggestedOrbits.forEach((orb) => suggestedOrbitTypes.add(orb));
  });

  // Sort orbits with suggested ones first
  return [...ORBITS].sort((a, b) => {
    const aSuggested = suggestedOrbitTypes.has(a.type);
    const bSuggested = suggestedOrbitTypes.has(b.type);
    if (aSuggested && !bSuggested) return -1;
    if (!aSuggested && bSuggested) return 1;
    return 0;
  });
}
