// ============================================================================
// CubeSat Mission Designer — Scientific Objectives Data
// ============================================================================

import type { ScientificObjective } from '../types/mission';

export const OBJECTIVES: ScientificObjective[] = [
  // ── Earth Observation ──────────────────────────────────────────────────
  {
    id: 'climate-monitoring',
    domain: 'earth-observation',
    name: { en: 'Climate Monitoring', vi: 'Giám sát Khí hậu' },
    description: {
      en: 'Monitor atmospheric CO₂, methane, and temperature trends to track global climate change.',
      vi: 'Giám sát CO₂, methane và xu hướng nhiệt độ trong khí quyển để theo dõi biến đổi khí hậu toàn cầu.',
    },
    icon: '🌡️',
    compatibleWavelengths: ['infrared', 'microwave'],
    suggestedOrbits: ['LEO', 'SSO'],
    difficulty: 2,
  },
  {
    id: 'weather-forecasting',
    domain: 'earth-observation',
    name: { en: 'Weather Forecasting', vi: 'Dự báo Thời tiết' },
    description: {
      en: 'Capture cloud patterns, humidity profiles, and sea-surface temperatures for weather prediction models.',
      vi: 'Chụp hình mây, profil độ ẩm và nhiệt độ bề mặt biển để phục vụ mô hình dự báo thời tiết.',
    },
    icon: '⛅',
    compatibleWavelengths: ['visible', 'infrared', 'microwave'],
    suggestedOrbits: ['SSO', 'GEO'],
    difficulty: 1,
  },
  {
    id: 'ocean-color',
    domain: 'earth-observation',
    name: { en: 'Ocean Color Science', vi: 'Khoa học Màu sắc Đại dương' },
    description: {
      en: 'Measure ocean color to map phytoplankton distributions, water quality, and marine ecosystems.',
      vi: 'Đo màu đại dương để lập bản đồ phân bố thực vật phù du, chất lượng nước và hệ sinh thái biển.',
    },
    icon: '🌊',
    compatibleWavelengths: ['visible', 'ultraviolet'],
    suggestedOrbits: ['SSO', 'LEO'],
    difficulty: 2,
  },
  {
    id: 'land-use-mapping',
    domain: 'earth-observation',
    name: { en: 'Land Use Mapping', vi: 'Lập bản đồ Sử dụng Đất' },
    description: {
      en: 'Map urban expansion, deforestation, and agricultural land use with multispectral imaging.',
      vi: 'Lập bản đồ mở rộng đô thị, phá rừng và sử dụng đất nông nghiệp bằng ảnh đa phổ.',
    },
    icon: '🗺️',
    compatibleWavelengths: ['visible', 'infrared'],
    suggestedOrbits: ['SSO', 'LEO'],
    difficulty: 1,
  },

  // ── Astrophysics ───────────────────────────────────────────────────────
  {
    id: 'star-formation',
    domain: 'astrophysics',
    name: { en: 'Star Formation Study', vi: 'Nghiên cứu Sự hình thành Sao' },
    description: {
      en: 'Observe stellar nurseries in the infrared to understand how stars and planetary systems form.',
      vi: 'Quan sát vùng hình thành sao bằng hồng ngoại để hiểu cách sao và hệ hành tinh hình thành.',
    },
    icon: '⭐',
    compatibleWavelengths: ['infrared', 'radio'],
    suggestedOrbits: ['L2', 'HEO'],
    difficulty: 3,
  },
  {
    id: 'exoplanet-detection',
    domain: 'astrophysics',
    name: { en: 'Exoplanet Detection', vi: 'Phát hiện Ngoại hành tinh' },
    description: {
      en: 'Detect exoplanets via the transit method by measuring precise stellar brightness variations.',
      vi: 'Phát hiện ngoại hành tinh qua phương pháp quá cảnh bằng cách đo biến đổi độ sáng sao chính xác.',
    },
    icon: '🪐',
    compatibleWavelengths: ['visible', 'infrared'],
    suggestedOrbits: ['HEO', 'L2'],
    difficulty: 3,
  },
  {
    id: 'galaxy-survey',
    domain: 'astrophysics',
    name: { en: 'Galaxy Survey', vi: 'Khảo sát Thiên hà' },
    description: {
      en: 'Survey distant galaxies across multiple wavelengths to study cosmic evolution and dark matter.',
      vi: 'Khảo sát thiên hà xa ở nhiều bước sóng để nghiên cứu tiến hóa vũ trụ và vật chất tối.',
    },
    icon: '🌌',
    compatibleWavelengths: ['ultraviolet', 'visible', 'x-ray'],
    suggestedOrbits: ['L2', 'HEO'],
    difficulty: 3,
  },

  // ── Heliophysics ───────────────────────────────────────────────────────
  {
    id: 'solar-wind',
    domain: 'heliophysics',
    name: { en: 'Solar Wind Measurement', vi: 'Đo Gió Mặt trời' },
    description: {
      en: 'Measure solar wind particle flux, velocity, and magnetic field to study the Sun-Earth connection.',
      vi: 'Đo thông lượng hạt gió mặt trời, vận tốc và từ trường để nghiên cứu liên kết Mặt trời-Trái đất.',
    },
    icon: '☀️',
    compatibleWavelengths: ['ultraviolet', 'x-ray'],
    suggestedOrbits: ['L1', 'HEO'],
    difficulty: 2,
  },
  {
    id: 'space-weather',
    domain: 'heliophysics',
    name: { en: 'Space Weather Monitoring', vi: 'Giám sát Thời tiết Vũ trụ' },
    description: {
      en: 'Monitor energetic particle events, radiation belts, and geomagnetic disturbances.',
      vi: 'Giám sát sự kiện hạt năng lượng, vành đai bức xạ và nhiễu động từ trường Trái đất.',
    },
    icon: '🌐',
    compatibleWavelengths: ['radio', 'ultraviolet', 'x-ray'],
    suggestedOrbits: ['MEO', 'GEO', 'L1'],
    difficulty: 2,
  },

  // ── Planetary Science ──────────────────────────────────────────────────
  {
    id: 'lunar-mapping',
    domain: 'planetary-science',
    name: { en: 'Lunar Surface Mapping', vi: 'Lập bản đồ Bề mặt Mặt trăng' },
    description: {
      en: 'Map the lunar surface composition, topography, and identify resources for future exploration.',
      vi: 'Lập bản đồ thành phần, địa hình bề mặt Mặt trăng và xác định tài nguyên cho thám hiểm tương lai.',
    },
    icon: '🌙',
    compatibleWavelengths: ['visible', 'infrared'],
    suggestedOrbits: ['lunar'],
    difficulty: 3,
  },
  {
    id: 'asteroid-study',
    domain: 'planetary-science',
    name: { en: 'Asteroid Characterization', vi: 'Đặc tính hóa Tiểu hành tinh' },
    description: {
      en: 'Study near-Earth asteroid composition, shape, and rotation for planetary defense and resource assessment.',
      vi: 'Nghiên cứu thành phần, hình dạng và tự quay của tiểu hành tinh gần Trái đất để bảo vệ hành tinh.',
    },
    icon: '☄️',
    compatibleWavelengths: ['visible', 'infrared', 'radio'],
    suggestedOrbits: ['interplanetary', 'HEO'],
    difficulty: 3,
  },

  // ── Technology Demo ────────────────────────────────────────────────────
  {
    id: 'comm-relay',
    domain: 'technology-demo',
    name: { en: 'Communication Relay', vi: 'Tiếp sóng Thông tin' },
    description: {
      en: 'Demonstrate CubeSat-based inter-satellite communication relay for future constellation networks.',
      vi: 'Trình diễn tiếp sóng liên vệ tinh dựa trên CubeSat cho mạng chùm vệ tinh tương lai.',
    },
    icon: '📡',
    compatibleWavelengths: ['radio', 'microwave'],
    suggestedOrbits: ['LEO', 'MEO'],
    difficulty: 1,
  },
];
