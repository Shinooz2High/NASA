// ============================================================================
// CubeSat Mission Designer — Optical & Antenna Systems Data
// ============================================================================

import type { OpticalSystem } from '../types/mission';

export const OPTICS: OpticalSystem[] = [
  {
    id: 'cassegrain-reflector',
    name: { en: 'Cassegrain Folded Reflector (0.085 m)', vi: 'Kính Phản xạ Gập Cassegrain (0.085 m)' },
    description: {
      en: 'Compact reflective telescope using parabolic primary and hyperbolic secondary mirrors for high focal length in a 1U-2U volume envelope.',
      vi: 'Kính viễn vọng phản xạ gọn gàng sử dụng gương chính parabol và gương phụ hyperbol, tiêu cự dài trong thể tích 1U-2U.',
    },
    type: 'reflector',
    aperture: 0.085,
    mass: 0.75,
    fov: 2.4,
    volume: 1.2,
    compatibleWavelengths: ['visible', 'infrared', 'ultraviolet'],
    minSize: '2U',
  },
  {
    id: 'compact-refractor',
    name: { en: 'Achromatic Refractor Lens Array', vi: 'Hệ Thấu kính Khúc xạ Sắc sai' },
    description: {
      en: 'Multi-element optical glass assembly optimized for wide field of view, ruggedness, and sharp visible/UV imaging.',
      vi: 'Cụm thấu kính quang học nhiều lớp tối ưu hóa cho trường nhìn rộng, chống rung chấn và ảnh quang học/UV sắc nét.',
    },
    type: 'refractor',
    aperture: 0.045,
    mass: 0.35,
    fov: 6.8,
    volume: 0.5,
    compatibleWavelengths: ['visible', 'ultraviolet'],
    minSize: '1U',
  },
  {
    id: 'uhf-dipole-antenna',
    name: { en: 'Deployable Tape-Spring UHF Dipole', vi: 'Ăng-ten Lưỡng cực UHF Bung Thước cuộn' },
    description: {
      en: 'Omnidirectional spring-steel deployable dipole antenna offering near-spherical coverage for telemetry and radio beacon reception.',
      vi: 'Ăng-ten lưỡng cực bằng thép lò xo tự bung đa hướng, vùng phủ gần như hình cầu cho đo xa và thu tín hiệu vô tuyến.',
    },
    type: 'antenna-dish',
    aperture: 0.35,
    mass: 0.18,
    fov: 180.0,
    volume: 0.2,
    compatibleWavelengths: ['radio'],
    minSize: '1U',
  },
  {
    id: 's-band-patch-array',
    name: { en: 'S-band Microstrip Patch Array Antenna', vi: 'Dàn Ăng-ten Vi dải S-band Patch' },
    description: {
      en: 'Body-mounted microstrip patch array providing directional gain up to 8 dBi for medium-speed data downlinks and radar reception.',
      vi: 'Mảng ăng-ten dán phẳng trên thân vệ tinh với độ lợi định hướng lên đến 8 dBi cho truyền dữ liệu tốc độ trung bình và radar.',
    },
    type: 'phased-array',
    aperture: 0.12,
    mass: 0.28,
    fov: 65.0,
    volume: 0.3,
    compatibleWavelengths: ['microwave', 'radio'],
    minSize: '2U',
  },
  {
    id: 'deployable-mesh-antenna',
    name: { en: 'Deployable Parabolic Mesh Reflector (0.5 m)', vi: 'Gương Phản xạ Lưới Parabol Tự bung (0.5 m)' },
    description: {
      en: 'Spring-loaded carbon fiber rib umbrella mechanism unfurling a gold-plated molybdenum mesh dish for high-gain SAR radar and Ka/X-band comms.',
      vi: 'Cơ cấu bung ô nan sợi carbon mở ra chao phản xạ lưới mạ vàng 0.5m cho radar SAR và liên lạc băng X/Ka độ lợi cao.',
    },
    type: 'reflector',
    aperture: 0.5,
    mass: 1.4,
    fov: 12.0,
    volume: 1.5,
    compatibleWavelengths: ['microwave', 'radio'],
    minSize: '3U',
  },
  {
    id: 'deployable-boom',
    name: { en: '1.5-Meter CFRP Deployable Instrument Boom', vi: 'Cần Đỡ Thiết bị Bung 1.5m Sợi Carbon' },
    description: {
      en: 'Articulated composite boom extending magnetic and electric field sensors far beyond the spacecraft bus electromagnetic contamination bubble.',
      vi: 'Cần sợi carbon mở rộng 1.5m đưa các cảm biến từ trường ra xa vùng nhiễu điện từ của thân vệ tinh.',
    },
    type: 'deployable-boom',
    aperture: 1.5,
    mass: 0.42,
    fov: 360.0,
    volume: 0.4,
    compatibleWavelengths: ['radio', 'visible'],
    minSize: '1U',
  },
];
