// ============================================================================
// CubeSat Mission Designer — Orbital Parameters Data
// ============================================================================

import type { OrbitParameters } from '../types/mission';

export const ORBITS: OrbitParameters[] = [
  {
    type: 'LEO',
    altitude: 500,
    inclination: 51.6,
    eccentricity: 0.001,
    period: 94.6, // minutes
    eclipseFraction: 0.38, // ~36 minutes in shadow per 95 min orbit
    name: { en: 'Low Earth Orbit (LEO, 500 km)', vi: 'Quỹ đạo Trái đất Thấp (LEO, 500 km)' },
    description: {
      en: 'Standard low-inclination circular orbit (similar to ISS). Frequent passes, moderate radiation, launch-friendly rideshares.',
      vi: 'Quỹ đạo tròn nghiêng thấp chuẩn (tương tự ISS). Tần suất bay qua nhiều lần, mức bức xạ vừa phải, chi phí phóng chia sẻ tối ưu.',
    },
  },
  {
    type: 'SSO',
    altitude: 600,
    inclination: 97.8,
    eccentricity: 0.001,
    period: 96.7,
    eclipseFraction: 0.35,
    name: { en: 'Sun-Synchronous Orbit (SSO, 600 km)', vi: 'Quỹ đạo Đồng bộ Mặt trời (SSO, 600 km)' },
    description: {
      en: 'Passes over each surface coordinate at the identical local solar time daily. Gold standard for Earth observation, optical imaging, and crop monitoring.',
      vi: 'Bay qua từng tọa độ bề mặt tại cùng một giờ địa phương mỗi ngày. Tiêu chuẩn vàng cho viễn thám Trái đất, ảnh quang học và nông nghiệp.',
    },
  },
  {
    type: 'MEO',
    altitude: 2000,
    inclination: 55.0,
    eccentricity: 0.005,
    period: 127.0,
    eclipseFraction: 0.28,
    name: { en: 'Medium Earth Orbit (MEO, 2,000 km)', vi: 'Quỹ đạo Trái đất Trung bình (MEO, 2.000 km)' },
    description: {
      en: 'Larger ground footprint and longer contact windows, but passes through intense inner Van Allen radiation belts requiring rad-hardened electronics.',
      vi: 'Vùng phủ sóng mặt đất rộng hơn và thời gian liên lạc dài hơn, nhưng chịu bức xạ mạnh từ vành đai Van Allen đòi hỏi linh kiện kháng bức xạ.',
    },
  },
  {
    type: 'GEO',
    altitude: 35786,
    inclination: 0.0,
    eccentricity: 0.0001,
    period: 1436.1, // 24 hours
    eclipseFraction: 0.05, // Only brief eclipse during equinoxes
    name: { en: 'Geostationary Orbit (GEO, 35,786 km)', vi: 'Quỹ đạo Địa tĩnh (GEO, 35.786 km)' },
    description: {
      en: 'Spacecraft hovers perpetually over a fixed equatorial longitude. Ideal for continuous weather monitoring, space weather, and telecommunication relays.',
      vi: 'Vệ tinh đứng yên tương đối phía trên một kinh độ xích đạo cố định. Hoàn hảo cho giám sát bão thời tiết 24/7 và chuyển tiếp viễn thông.',
    },
  },
  {
    type: 'HEO',
    altitude: 39100, // Apogee
    inclination: 63.4,
    eccentricity: 0.72,
    period: 718.0, // 12 hours (Molniya-like)
    eclipseFraction: 0.15,
    name: { en: 'Highly Elliptical Orbit (Molniya / HEO)', vi: 'Quỹ đạo Elip Cao (HEO / Molniya)' },
    description: {
      en: 'Spends ~80% of its period loitering at high apogee over the northern polar regions and deep magnetosphere before rapid perigee sweeps.',
      vi: 'Dành ~80% chu kỳ ở viễn điểm vùng cực bắc và ngoài từ quyển sâu trước khi lướt nhanh qua cận điểm.',
    },
  },
  {
    type: 'lunar',
    altitude: 100, // Lunar orbit altitude
    inclination: 90.0,
    eccentricity: 0.01,
    period: 118.0,
    eclipseFraction: 0.42,
    name: { en: 'Low Lunar Polar Orbit (100 km)', vi: 'Quỹ đạo Cực Mặt trăng Thấp (100 km)' },
    description: {
      en: 'Orbits 100 km above the Moon, passing directly over both poles to map permanently shadowed craters, water ice reserves, and lunar crustal magnetism.',
      vi: 'Quỹ đạo 100 km quanh Mặt trăng, bay qua cả hai cực để lập bản đồ các miệng núi lửa bóng tối vĩnh viễn và trữ lượng băng nước.',
    },
  },
  {
    type: 'L1',
    altitude: 1500000, // 1.5 million km towards Sun
    inclination: 0,
    eccentricity: 0,
    period: 250000,
    eclipseFraction: 0.0, // Zero eclipse! 100% sunlight
    name: { en: 'Sun-Earth Lagrange Point L1 (Halo)', vi: 'Điểm Lagrange L1 Mặt trời - Trái đất' },
    description: {
      en: '1.5 million km sunward from Earth with uninterrupted 24/7 solar viewing and early warning of incoming coronal mass ejections (CMEs).',
      vi: 'Cách Trái đất 1.5 triệu km về hướng Mặt trời với góc nhìn Mặt trời 100% không bị che khuất và cảnh báo sớm bão từ CME.',
    },
  },
  {
    type: 'L2',
    altitude: 1500000, // 1.5 million km away from Sun
    inclination: 0,
    eccentricity: 0,
    period: 250000,
    eclipseFraction: 0.0, // Stays in halo outside Earth umbra
    name: { en: 'Sun-Earth Lagrange Point L2 (Halo)', vi: 'Điểm Lagrange L2 Mặt trời - Trái đất' },
    description: {
      en: 'Ultra-cold, thermally stable cosmic vantage point behind Earth, shielded from solar and terrestrial light. Premier orbit for space observatories.',
      vi: 'Vị trí siêu lạnh, ổn định nhiệt sau Trái đất, được che chắn khỏi ánh sáng chói của Mặt trời và Trái đất. Quỹ đạo tối ưu cho kính thiên văn.',
    },
  },
  {
    type: 'interplanetary',
    altitude: 150000000, // Heliocentric orbit ~1 AU
    inclination: 1.8,
    eccentricity: 0.12,
    period: 525600, // 1 year
    eclipseFraction: 0.0,
    name: { en: 'Heliocentric Interplanetary Trajectory', vi: 'Quỹ đạo Liên hành tinh Quanh Mặt trời' },
    description: {
      en: 'Leaves Earth gravity well on an escape trajectory towards Mars, Venus, or near-Earth asteroids, requiring autonomous navigation and high-gain links.',
      vi: 'Thoát khỏi lực hút Trái đất bay hướng về Sao Hỏa, Sao Kim hoặc tiểu hành tinh gần Trái đất, cần định vị tự hành và liên lạc cự ly xa.',
    },
  },
];
