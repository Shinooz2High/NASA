// ============================================================================
// CubeSat Mission Designer — Wavelength Bands Data
// ============================================================================

import type { Wavelength } from '../types/mission';

export const WAVELENGTHS: Wavelength[] = [
  {
    id: 'radio',
    name: { en: 'Radio', vi: 'Sóng Vô tuyến' },
    description: {
      en: 'Wavelengths longer than 1 mm, used for communication, radio astronomy, and radar remote sensing.',
      vi: 'Bước sóng dài hơn 1 mm, dùng cho thông tin liên lạc, thiên văn vô tuyến và viễn thám radar.',
    },
    range: '> 1 mm (< 300 GHz)',
    color: '#e74c3c',
    compatibleInstruments: ['radio-receiver', 'sar-radar'],
  },
  {
    id: 'microwave',
    name: { en: 'Microwave', vi: 'Vi sóng' },
    description: {
      en: 'Wavelengths from 1 mm to 1 m, used for atmospheric sounding, communication, and surface mapping.',
      vi: 'Bước sóng từ 1 mm đến 1 m, dùng cho thăm dò khí quyển, liên lạc và lập bản đồ bề mặt.',
    },
    range: '1 mm – 1 m (300 MHz – 300 GHz)',
    color: '#e67e22',
    compatibleInstruments: ['ir-radiometer', 'sar-radar', 'radio-receiver'],
  },
  {
    id: 'infrared',
    name: { en: 'Infrared', vi: 'Hồng ngoại' },
    description: {
      en: 'Wavelengths from 700 nm to 1 mm, essential for thermal sensing, atmospheric gases, and dust-obscured astronomy.',
      vi: 'Bước sóng từ 700 nm đến 1 mm, thiết yếu cho cảm biến nhiệt, khí quyển và thiên văn học qua bụi.',
    },
    range: '700 nm – 1 mm',
    color: '#c0392b',
    compatibleInstruments: ['multispectral-camera', 'hyperspectral-imager', 'ir-radiometer'],
  },
  {
    id: 'visible',
    name: { en: 'Visible', vi: 'Ánh sáng Khả kiến' },
    description: {
      en: 'Human-visible light from 380–700 nm, the workhorse of Earth imaging, star tracking, and optical astronomy.',
      vi: 'Ánh sáng mắt thường từ 380–700 nm, nền tảng chụp ảnh Trái đất, theo dõi sao và thiên văn quang học.',
    },
    range: '380 – 700 nm',
    color: '#2ecc71',
    compatibleInstruments: ['multispectral-camera', 'hyperspectral-imager', 'star-tracker-payload', 'lidar-altimeter'],
  },
  {
    id: 'ultraviolet',
    name: { en: 'Ultraviolet', vi: 'Tia Cực tím' },
    description: {
      en: 'Wavelengths from 10–380 nm, used for solar physics, ozone monitoring, and hot stellar objects.',
      vi: 'Bước sóng từ 10–380 nm, dùng cho vật lý mặt trời, giám sát ozone và các thiên thể nóng.',
    },
    range: '10 – 380 nm',
    color: '#8e44ad',
    compatibleInstruments: ['uv-spectrometer'],
  },
  {
    id: 'x-ray',
    name: { en: 'X-ray', vi: 'Tia X' },
    description: {
      en: 'Wavelengths from 0.01–10 nm, revealing high-energy phenomena like black holes, neutron stars, and solar flares.',
      vi: 'Bước sóng từ 0,01–10 nm, tiết lộ hiện tượng năng lượng cao như hố đen, sao neutron và bùng nổ mặt trời.',
    },
    range: '0.01 – 10 nm',
    color: '#3498db',
    compatibleInstruments: ['particle-detector'],
  },
  {
    id: 'gamma-ray',
    name: { en: 'Gamma-ray', vi: 'Tia Gamma' },
    description: {
      en: 'Wavelengths shorter than 0.01 nm, produced by the most energetic cosmic events: gamma-ray bursts and nuclear processes.',
      vi: 'Bước sóng ngắn hơn 0,01 nm, sinh ra từ các sự kiện năng lượng cao nhất: bùng phát tia gamma và quá trình hạt nhân.',
    },
    range: '< 0.01 nm (> 100 keV)',
    color: '#1abc9c',
    compatibleInstruments: ['particle-detector'],
  },
];
