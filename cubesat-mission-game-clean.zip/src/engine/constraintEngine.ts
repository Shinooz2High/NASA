// ============================================================================
// CubeSat Mission Designer — Constraint & Compatibility Engine
// ============================================================================

import type {
  CubeSatDesign,
} from '../types';
import {
  getCompatibleWavelengths,
  getCompatibleInstruments,
  getCompatibleOptics,
  getCompatibleOrbits,
  sizeToUnits,
} from '../data/compatibility';
import { INSTRUMENTS } from '../data/instruments';
import { OPTICS } from '../data/optics';

export {
  getCompatibleWavelengths,
  getCompatibleInstruments,
  getCompatibleOptics,
  getCompatibleOrbits,
  sizeToUnits,
};

export interface DesignValidation {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

/**
 * Validates a complete CubeSat design against physical, volume, and operational limits.
 */
export function validateDesign(design: CubeSatDesign): DesignValidation {
  const errors: string[] = [];
  const warnings: string[] = [];

  const busUnits = sizeToUnits(design.size);

  // 1. Check objectives
  if (design.objectives.length === 0) {
    errors.push('No scientific objectives selected.');
  }

  // 2. Check wavelengths
  if (design.wavelengths.length === 0) {
    errors.push('No observation wavelength bands selected.');
  }

  // 3. Check instruments
  if (design.instruments.length === 0) {
    errors.push('No payload instruments equipped.');
  }

  // 4. Volume constraint check: sum of instrument and optics volumes vs available bus volume
  const selectedInsts = INSTRUMENTS.filter((i) => design.instruments.includes(i.id));
  const selectedOptics = OPTICS.filter((o) => design.optics.includes(o.id));

  const totalPayloadVolume =
    selectedInsts.reduce((sum, i) => sum + i.volume, 0) +
    selectedOptics.reduce((sum, o) => sum + o.volume, 0);

  // Typically, 40-50% of CubeSat volume is occupied by bus (avionics, battery, ADCS, structure)
  const maxPayloadVolume = busUnits * 0.6;
  if (totalPayloadVolume > maxPayloadVolume) {
    errors.push(
      `Payload volume (${totalPayloadVolume.toFixed(1)}U) exceeds allowable allocation for a ${design.size} bus (${maxPayloadVolume.toFixed(1)}U).`
    );
  } else if (totalPayloadVolume > busUnits * 0.5) {
    warnings.push(
      `Payload packing density is tight (${totalPayloadVolume.toFixed(1)}U / ${busUnits}U). Routing cables may require custom harness.`
    );
  }

  // 5. Optics compatibility with instrument
  selectedInsts.forEach((inst) => {
    if (inst.compatibleOptics.length > 0 && selectedOptics.length > 0) {
      const hasMatch = selectedOptics.some((opt) =>
        inst.compatibleOptics.includes(opt.id)
      );
      if (!hasMatch) {
        warnings.push(
          `Instrument "${inst.name.en}" is optimized for ${inst.compatibleOptics.join(', ')}, but none are installed.`
        );
      }
    }
  });

  // 6. Deep space / lunar orbit checks
  if (design.orbit === 'lunar' || design.orbit === 'interplanetary') {
    if (design.comms.frequency === 'UHF') {
      warnings.push(
        'UHF band link margin over lunar or interplanetary distances is extremely weak. Consider upgrading to X-band.'
      );
    }
    if (design.propulsion.type === 'none') {
      warnings.push(
        'Deep space or lunar operations typically require an active propulsion system for trajectory correction.'
      );
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}
