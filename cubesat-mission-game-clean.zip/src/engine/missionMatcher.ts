// ============================================================================
// CubeSat Mission Designer — NASA Mission Matching Engine
// ============================================================================

import type { CubeSatDesign, MissionMatchResult, NasaMission } from '../types';
import { NASA_MISSIONS } from '../data/nasaMissions';
import { OBJECTIVES } from '../data/objectives';
import { INSTRUMENTS } from '../data/instruments';

export function findMatchingMissions(
  design: CubeSatDesign,
  limit = 3
): MissionMatchResult[] {
  const selectedObjs = OBJECTIVES.filter((o) => design.objectives.includes(o.id));
  const userDomains = Array.from(new Set(selectedObjs.map((o) => o.domain)));
  const userWavelengths = design.wavelengths;
  const userInstruments = INSTRUMENTS.filter((i) =>
    design.instruments.includes(i.id)
  ).map((i) => i.type);

  const scoredMissions = NASA_MISSIONS.map((mission: NasaMission) => {
    // 1. Scientific Domain Match (30%)
    const domainMatches = mission.objectives.filter((d) => userDomains.includes(d));
    const domainScore =
      mission.objectives.length > 0
        ? Math.round((domainMatches.length / mission.objectives.length) * 100)
        : 0;

    // 2. Wavelength Overlap (25%)
    const waveMatches = mission.wavelengths.filter((w) =>
      userWavelengths.includes(w)
    );
    const wavelengthScore =
      mission.wavelengths.length > 0
        ? Math.round((waveMatches.length / mission.wavelengths.length) * 100)
        : 0;

    // 3. Orbit Match (20%)
    let orbitScore = 0;
    if (mission.orbit === design.orbit) {
      orbitScore = 100;
    } else if (
      (mission.orbit === 'LEO' && design.orbit === 'SSO') ||
      (mission.orbit === 'SSO' && design.orbit === 'LEO') ||
      (mission.orbit === 'L1' && design.orbit === 'L2') ||
      (mission.orbit === 'L2' && design.orbit === 'L1')
    ) {
      orbitScore = 65;
    }

    // 4. Instrument Complement Match (15%)
    const instMatches = mission.instrumentTypes.filter((t) =>
      userInstruments.includes(t as any)
    );
    const instrumentScore =
      mission.instrumentTypes.length > 0
        ? Math.round((instMatches.length / mission.instrumentTypes.length) * 100)
        : 0;

    // 5. Scale / Architecture bonus (10%)
    let scaleScore = 50;
    if (mission.isCubesat) {
      scaleScore = 100; // Extra credit for CubeSat sibling!
    }

    // Weighted Overall Score
    const overallScore = Math.round(
      domainScore * 0.3 +
        wavelengthScore * 0.25 +
        orbitScore * 0.2 +
        instrumentScore * 0.15 +
        scaleScore * 0.1
    );

    // Human-readable match reasons
    const matchReasons: Array<{ en: string; vi: string }> = [];

    if (domainMatches.length > 0) {
      matchReasons.push({
        en: `Shared scientific domain: ${domainMatches.join(', ')}`,
        vi: `Chung lĩnh vực khoa học: ${domainMatches.join(', ')}`,
      });
    }

    if (waveMatches.length > 0) {
      matchReasons.push({
        en: `Coincident observation wavelengths: ${waveMatches.join(', ')}`,
        vi: `Quan sát cùng dải bước sóng: ${waveMatches.join(', ')}`,
      });
    }

    if (orbitScore === 100) {
      matchReasons.push({
        en: `Identical orbital regime: ${mission.orbit}`,
        vi: `Cùng môi trường quỹ đạo: ${mission.orbit}`,
      });
    }

    if (instMatches.length > 0) {
      matchReasons.push({
        en: `Matching payload instrumentation: ${instMatches.join(', ')}`,
        vi: `Trang bị thiết bị tương đồng: ${instMatches.join(', ')}`,
      });
    }

    if (mission.isCubesat) {
      matchReasons.push({
        en: `Pioneering small satellite / CubeSat heritage mission`,
        vi: `Thuộc dòng vệ tinh nhỏ / CubeSat tiên phong của NASA`,
      });
    }

    return {
      mission,
      overallScore: Math.min(99, overallScore),
      domainScore,
      wavelengthScore,
      orbitScore,
      instrumentScore,
      scaleScore,
      matchReasons,
    };
  });

  // Sort descending by score and pick top N
  return scoredMissions
    .sort((a, b) => b.overallScore - a.overallScore)
    .slice(0, limit);
}
