// ============================================================================
// CubeSat Mission Designer — Cost Estimation Model (NASA SSCM)
// ============================================================================

import type { CostEstimateResult, CubeSatDesign } from '../../types';
import { sizeToUnits } from '../../data/compatibility';
import { INSTRUMENTS } from '../../data/instruments';

export function calculateCostEstimate(
  design: CubeSatDesign,
  wetMassKg: number
): CostEstimateResult {
  const units = sizeToUnits(design.size);

  // 1. Hardware Subsystem Costs ($USD)
  // Base bus components
  let busHardware = 35000 * units; // Structure, EPS base, harness

  // Solar cells & batteries
  if (design.power.solarCellType === 'triple-junction') busHardware += 18000 * units;
  if (design.power.solarPanelType === 'deployable-tracking') busHardware += 25000;
  busHardware += (design.power.batteryCapacity / 20) * 4500;

  // Comms
  if (design.comms.frequency === 'UHF') busHardware += 8000;
  if (design.comms.frequency === 'S-band') busHardware += 22000;
  if (design.comms.frequency === 'X-band') busHardware += 48000;
  if (design.comms.frequency === 'Ka-band') busHardware += 85000;

  // ADCS
  busHardware += design.adcs.sensors.length * 6000;
  busHardware += design.adcs.actuators.length * 14000;

  // Propulsion engine
  if (design.propulsion.type === 'cold-gas') busHardware += 28000;
  if (design.propulsion.type === 'resistojet') busHardware += 45000;
  if (design.propulsion.type === 'ion') busHardware += 95000;
  if (design.propulsion.type === 'hall-effect') busHardware += 120000;

  // Payload instruments cost
  const selectedInsts = INSTRUMENTS.filter((i) => design.instruments.includes(i.id));
  const payloadHardware = selectedInsts.length * 45000 + (design.optics.length * 20000);

  const hardware = Math.round(busHardware + payloadHardware);

  // 2. Flight Software Development & Ground Tools (~25% of hardware)
  const software = Math.round(hardware * 0.25);

  // 3. Assembly, Integration & Verification (AI&V) (~18% of hardware)
  const integration = Math.round(hardware * 0.18);

  // 4. Environmental Testing (Vibration table, Thermal Vacuum TVAC) (~14% of hardware)
  const testing = Math.round(hardware * 0.14);

  // 5. Launch Rideshare Cost
  // Standard CubeSat rideshare pricing: ~$45,000 per U for standard LEO rideshare (e.g. SpaceX Transporter)
  // Higher for deep space or dedicated lunar deployment
  let launchPerUnit = 45000;
  if (design.orbit === 'GEO' || design.orbit === 'HEO') launchPerUnit = 75000;
  if (design.orbit === 'lunar' || design.orbit === 'interplanetary') launchPerUnit = 120000;

  const launchCost = Math.round(units * launchPerUnit);

  // 6. Mission Operations (Ground station network access, amateur radio coordination, cloud processing)
  const operations = Math.round(design.missionDuration * 4500);

  // Total Lifecycle Cost
  const totalCost = hardware + software + integration + testing + launchCost + operations;

  const costPerKg = wetMassKg > 0 ? Math.round(totalCost / wetMassKg) : 0;

  let costCategory: 'low' | 'medium' | 'high' | 'very-high' = 'low';
  if (totalCost > 1500000) costCategory = 'very-high';
  else if (totalCost > 800000) costCategory = 'high';
  else if (totalCost > 400000) costCategory = 'medium';

  return {
    hardware,
    software,
    integration,
    testing,
    launchCost,
    operations,
    totalCost,
    costPerKg,
    costCategory,
  };
}
