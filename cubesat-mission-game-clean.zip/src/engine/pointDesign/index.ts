// ============================================================================
// CubeSat Mission Designer — Point Design Aggregator (CML 3/4)
// ============================================================================

import type { CubeSatDesign, PointDesignResult } from '../../types';
import { ORBITS } from '../../data/orbits';
import { calculatePowerBudget } from './powerBudget';
import { calculateLinkBudget } from './linkBudget';
import { calculateThermalBalance } from './thermalAnalysis';
import { calculateMassBudget } from './massBudget';
import { calculatePropulsion } from './propulsion';
import { calculateCostEstimate } from './costModel';

export function calculatePointDesign(design: CubeSatDesign): PointDesignResult {
  const orbit =
    ORBITS.find((o) => o.type === design.orbit) ||
    ORBITS[0];

  // 1. Calculate Individual Subsystem Budgets
  const power = calculatePowerBudget(design, orbit);
  const link = calculateLinkBudget(design, orbit);
  const thermal = calculateThermalBalance(design, orbit);
  const mass = calculateMassBudget(design);
  const propulsion = calculatePropulsion(design);
  const cost = calculateCostEstimate(design, mass.totalMass);

  // 2. Feasibility Scoring (0-100)
  let score = 100;
  const recommendations: PointDesignResult['recommendations'] = [];

  // Power checks
  if (power.status === 'critical') {
    score -= 30;
    recommendations.push({
      category: 'Power',
      severity: 'critical',
      message: {
        en: 'Deployable solar arrays or higher efficiency triple-junction cells are required to prevent battery starvation.',
        vi: 'Cần bổ sung tấm pin mặt trời bung hoặc chuyển sang pin ba mối nối (triple-junction) để tránh cạn kiệt điện.',
      },
    });
  } else if (power.status === 'warning') {
    score -= 10;
    recommendations.push({
      category: 'Power',
      severity: 'warning',
      message: {
        en: 'Power margin is tight (<20%). Consider increasing battery capacity or duty-cycling high-power instruments.',
        vi: 'Biên nguồn điện thấp (<20%). Nên tăng dung lượng pin lưu trữ hoặc giảm thời gian hoạt động của tải trọng nặng.',
      },
    });
  }

  // Link checks
  if (link.status === 'critical') {
    score -= 25;
    recommendations.push({
      category: 'Communications',
      severity: 'critical',
      message: {
        en: 'Negative link margin: Upgrade RF frequency to S-band/X-band or increase RF transmit power.',
        vi: 'Biên đường truyền âm: Nâng cấp tần số vô tuyến lên băng S/X hoặc tăng công suất phát sóng.',
      },
    });
  } else if (link.status === 'warning') {
    score -= 8;
    recommendations.push({
      category: 'Communications',
      severity: 'warning',
      message: {
        en: 'Link margin is under 3 dB. High-gain antenna or longer contact passes will reduce frame loss.',
        vi: 'Biên đường truyền dưới 3 dB. Ăng-ten độ lợi cao hơn sẽ giảm nguy cơ mất gói tin.',
      },
    });
  }

  // Thermal checks
  if (thermal.status === 'critical') {
    score -= 25;
    recommendations.push({
      category: 'Thermal',
      severity: 'critical',
      message: {
        en: 'Thermal limits violated. Multi-Layer Insulation (MLI) blankets and radiator panels are needed.',
        vi: 'Vượt giới hạn nhiệt độ an toàn. Cần bổ sung lớp cách nhiệt MLI và tấm tản nhiệt ngoài thân.',
      },
    });
  } else if (thermal.status === 'warning') {
    score -= 8;
    recommendations.push({
      category: 'Thermal',
      severity: 'warning',
      message: {
        en: 'Spacecraft runs slightly cold in eclipse. Enable active electric heaters for battery health.',
        vi: 'Tàu hơi lạnh khi đi vào vùng bóng tối. Bật bộ sưởi chủ động để bảo vệ cell pin lithium.',
      },
    });
  }

  // Mass checks
  if (mass.status === 'critical') {
    score -= 30;
    recommendations.push({
      category: 'Structures & Mass',
      severity: 'critical',
      message: {
        en: `Total mass (${mass.totalMass} kg) exceeds ${design.size} deployer limit (${mass.maxMass} kg). Upsize bus or remove heavy payloads.`,
        vi: `Tổng khối lượng (${mass.totalMass} kg) vượt tiêu chuẩn ống phóng ${design.size} (${mass.maxMass} kg). Hãy nâng cỡ khung hoặc giảm tải.`,
      },
    });
  } else if (mass.status === 'warning') {
    score -= 6;
    recommendations.push({
      category: 'Structures & Mass',
      severity: 'warning',
      message: {
        en: 'Mass margin is less than 15%. Lightweight composite materials or harness trimming recommended.',
        vi: 'Biên khối lượng dưới 15%. Cần xem xét vật liệu composite nhẹ hơn để đáp ứng dự phòng trước khi xuất xưởng.',
      },
    });
  }

  // Propulsion checks
  if (propulsion.status === 'warning') {
    score -= 5;
    recommendations.push({
      category: 'Propulsion',
      severity: 'info',
      message: {
        en: 'Propellant mass is low. Ensure lifetime atmospheric decay complies with orbital debris mitigation standards.',
        vi: 'Lượng nhiên liệu đẩy ít. Đảm bảo thời gian tự phân hủy trong khí quyển tuân thủ quy định chống rác vũ trụ.',
      },
    });
  }

  const feasibilityScore = Math.max(0, Math.min(100, score));

  let overallFeasibility: 'feasible' | 'marginal' | 'infeasible' = 'feasible';
  if (
    power.status === 'critical' ||
    link.status === 'critical' ||
    thermal.status === 'critical' ||
    mass.status === 'critical'
  ) {
    overallFeasibility = 'infeasible';
  } else if (feasibilityScore < 75) {
    overallFeasibility = 'marginal';
  }

  if (recommendations.length === 0) {
    recommendations.push({
      category: 'System Integration',
      severity: 'info',
      message: {
        en: 'Exceptional point design! All subsystem power, link, thermal, and mass budgets are safely closed with positive margins.',
        vi: 'Thiết kế Point Design xuất sắc! Toàn bộ các phân hệ nguồn điện, liên lạc, nhiệt và khối lượng đều khép kín an toàn.',
      },
    });
  }

  return {
    power,
    link,
    thermal,
    mass,
    propulsion,
    cost,
    overallFeasibility,
    feasibilityScore,
    recommendations,
  };
}
