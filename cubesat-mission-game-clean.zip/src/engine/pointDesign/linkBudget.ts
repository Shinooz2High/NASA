// ============================================================================
// CubeSat Mission Designer — Link Budget Engine
// ============================================================================

import type { CubeSatDesign, LinkBudgetResult, OrbitParameters } from '../../types';

/**
 * Speed of light (m/s)
 */
const C = 299792458;
/**
 * Boltzmann constant (J/K)
 */
const K_BOLTZMANN = 1.380649e-23;

export function calculateLinkBudget(
  design: CubeSatDesign,
  orbit: OrbitParameters
): LinkBudgetResult {
  // 1. Frequency (Hz) & Spacecraft Antenna Gain (dBi)
  let freqHz = 437e6; // UHF
  let txGainDbi = 2.1; // Dipole
  let atmosphericLossDb = 0.5;

  switch (design.comms.frequency) {
    case 'UHF':
      freqHz = 437e6;
      txGainDbi = design.comms.antennaType === 'dipole' ? 2.1 : 3.0;
      atmosphericLossDb = 0.4;
      break;
    case 'S-band':
      freqHz = 2.2e9;
      txGainDbi = design.comms.antennaType === 'patch' ? 7.5 : 5.0;
      atmosphericLossDb = 0.6;
      break;
    case 'X-band':
      freqHz = 8.4e9;
      txGainDbi = design.comms.antennaType === 'horn' ? 14.0 : 12.0;
      atmosphericLossDb = 1.2;
      break;
    case 'Ka-band':
      freqHz = 26.0e9;
      txGainDbi =
        design.comms.antennaType === 'parabolic' ||
        design.comms.antennaType === 'phased-array'
          ? 26.0
          : 18.0;
      atmosphericLossDb = 2.5;
      break;
  }

  // Wavelength (m)
  const lambda = C / freqHz;

  // 2. Transmitter Power in dBW
  // P (W) -> P (dBW) = 10 * log10(P)
  const txPowerW = Math.max(0.1, design.comms.transmitPower);
  const txPowerDbw = 10 * Math.log10(txPowerW);

  // Spacecraft cable & implementation losses (~1.5 dB)
  const txLossDb = 1.5;

  // Equivalent Isotropically Radiated Power (EIRP)
  const eirp = txPowerDbw - txLossDb + txGainDbi;

  // 3. Free Space Path Loss (FSPL)
  // Distance to ground station (km -> m)
  let slantRangeKm = orbit.altitude;
  if (orbit.type === 'LEO' || orbit.type === 'SSO') {
    // Slant range at 10 deg elevation is roughly 2.2x altitude
    slantRangeKm = orbit.altitude * 2.2;
  } else if (orbit.type === 'GEO') {
    slantRangeKm = 38000;
  } else if (orbit.type === 'lunar') {
    slantRangeKm = 384400; // Earth-Moon distance
  } else if (orbit.type === 'L1' || orbit.type === 'L2') {
    slantRangeKm = 1500000;
  } else if (orbit.type === 'interplanetary') {
    slantRangeKm = 50000000; // 50 million km
  }

  const distanceM = slantRangeKm * 1000;
  const pathLoss = 20 * Math.log10((4 * Math.PI * distanceM) / lambda);

  // 4. Ground Station Parameters
  // Assume a standard university or commercial ground station (3m dish for LEO, 11m for deep space/lunar)
  let rxGainDbi = 20.0;
  if (design.comms.frequency === 'UHF') rxGainDbi = 16.0;
  if (design.comms.frequency === 'S-band') rxGainDbi = 28.0;
  if (design.comms.frequency === 'X-band') rxGainDbi = 38.0;
  if (design.comms.frequency === 'Ka-band') rxGainDbi = 45.0;

  if (orbit.type === 'lunar' || orbit.type === 'interplanetary') {
    // NASA DSN 34-meter class ground station
    rxGainDbi += 18.0;
  }

  // System noise temperature (K)
  const noiseTemperature =
    design.comms.frequency === 'Ka-band'
      ? 220
      : design.comms.frequency === 'X-band'
      ? 160
      : 130;

  // Received power (dBW)
  const receivedPower = eirp - pathLoss - atmosphericLossDb + rxGainDbi;

  // 5. Target Data Rate & SNR
  // Base nominal data rate in kbps based on band
  let baseDataRate = 9.6; // kbps for UHF
  if (design.comms.frequency === 'S-band') baseDataRate = 1000; // 1 Mbps
  if (design.comms.frequency === 'X-band') baseDataRate = 10000; // 10 Mbps
  if (design.comms.frequency === 'Ka-band') baseDataRate = 50000; // 50 Mbps

  // Range penalty factor
  if (slantRangeKm > 100000) {
    baseDataRate = Math.max(1.0, baseDataRate * 0.005);
  } else if (slantRangeKm > 5000) {
    baseDataRate = Math.max(2.0, baseDataRate * 0.05);
  }

  const achievableDataRate = Number(baseDataRate.toFixed(1));

  // Noise power spectral density N0 (dBW/Hz) = 10 * log10(k * T)
  const n0 = 10 * Math.log10(K_BOLTZMANN * noiseTemperature);

  // Bandwidth (Hz) roughly matches data rate for BPSK/QPSK
  const bandwidthHz = achievableDataRate * 1000 * 1.2;
  const totalNoiseDbw = n0 + 10 * Math.log10(bandwidthHz);

  // SNR (dB)
  const snr = Number((receivedPower - totalNoiseDbw).toFixed(1));
  const requiredSnr = 6.0; // dB for BER 10^-5 with FEC
  const margin = Number((snr - requiredSnr).toFixed(1));

  // 6. Ground Station Passes & Daily Data Volume
  // In LEO, pass duration is typically 8–10 minutes, with ~4 visible passes/day for a single ground station
  let contactTimePerOrbit = 8.5; // minutes
  let contactsPerDay = 4;
  let orbitsPerDay = orbit.period > 0 ? (24 * 60) / orbit.period : 1;

  if (orbit.type === 'GEO' || orbit.type === 'L1' || orbit.type === 'L2') {
    contactTimePerOrbit = orbit.period;
    contactsPerDay = 1; // Continuous
  }

  // Daily data volume (MB) = rate (kbps) * seconds / (8 * 1024)
  const totalContactSeconds =
    orbit.type === 'GEO' || orbit.type === 'L1' || orbit.type === 'L2'
      ? 24 * 3600 * 0.4 // 40% duty cycle
      : contactsPerDay * contactTimePerOrbit * 60;

  const dailyDataVolume = Math.round(
    (achievableDataRate * 1000 * totalContactSeconds) / (8 * 1024 * 1024)
  );

  // 7. Status & Details
  let status: 'ok' | 'warning' | 'critical' = 'ok';
  const details: string[] = [];

  if (margin < 0) {
    status = 'critical';
    details.push('Negative link margin: signal will not close; communication loss expected.');
  } else if (margin < 3.0) {
    status = 'warning';
    details.push('Slim link margin (< 3 dB). Risk of frame drops during rain fade or pointing jitter.');
  } else {
    details.push('Robust RF link (> 3 dB margin). Signal closed reliably.');
  }

  return {
    eirp: Number(eirp.toFixed(1)),
    pathLoss: Number(pathLoss.toFixed(1)),
    atmosphericLoss: atmosphericLossDb,
    receivedPower: Number(receivedPower.toFixed(1)),
    noiseTemperature,
    snr,
    requiredSnr,
    dataRate: achievableDataRate,
    contactTimePerOrbit: Number(contactTimePerOrbit.toFixed(1)),
    orbitsPerDay: Number(orbitsPerDay.toFixed(1)),
    contactsPerDay,
    dailyDataVolume,
    margin,
    status,
    details,
  };
}
