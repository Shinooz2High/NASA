// ============================================================================
// CubeSat Mission Designer — Mass Budget Engine
// ============================================================================

import type { CubeSatDesign, MassBudgetResult } from '../../types';
import { INSTRUMENTS } from '../../data/instruments';
import { OPTICS } from '../../data/optics';
import { sizeToUnits } from '../../data/compatibility';

export function calculateMassBudget(design: CubeSatDesign): MassBudgetResult {
  const units = sizeToUnits(design.size);

  // Maximum allowable launch mass according to CubeSat Design Specification (CDS)
  // Standard CDS: ~2.0 kg per U (or up to 1.33 kg/U in strict P-POD, modern dispensers allow up to 2 kg/U)
  const maxMass = units * 2.0;

  // 1. Structure (aluminum primary structure, rails, fasteners, brackets)
  // ~18% of max mass
  const structure = Number((maxMass * 0.18).toFixed(2));

  // 2. Power Subsystem
  // Batteries: ~150 Wh/kg specific energy + 25% packaging
  const batteryMass = (design.power.batteryCapacity / 150) * 1.25;
  // Solar panels: body-mounted vs deployables
  let panelMass = units * 0.08;
  if (design.power.solarPanelType === 'deployable-fixed') panelMass = units * 0.22;
  if (design.power.solarPanelType === 'deployable-tracking') panelMass = units * 0.35;
  // Power Distribution & Regulation board (PDU)
  const pduMass = 0.18;
  const power = Number((batteryMass + panelMass + pduMass).toFixed(2));

  // 3. Communications
  let commsMass = 0.25; // Base transceiver
  if (design.comms.frequency === 'S-band') commsMass = 0.45;
  if (design.comms.frequency === 'X-band') commsMass = 0.75;
  if (design.comms.frequency === 'Ka-band') commsMass = 1.1;
  const comms = Number(commsMass.toFixed(2));

  // 4. Thermal
  let thermalMass = 0.08;
  if (design.thermal.mli) thermalMass += 0.05 * units;
  if (design.thermal.radiators) thermalMass += 0.15;
  if (design.thermal.heaters) thermalMass += 0.06;
  const thermal = Number(thermalMass.toFixed(2));

  // 5. Propulsion
  // Dry engine mass + propellant mass
  let engineDryMass = 0.0;
  if (design.propulsion.type === 'cold-gas') engineDryMass = 0.6;
  if (design.propulsion.type === 'resistojet') engineDryMass = 0.8;
  if (design.propulsion.type === 'ion') engineDryMass = 1.2;
  if (design.propulsion.type === 'hall-effect') engineDryMass = 1.6;

  const propulsion = Number(
    (engineDryMass + design.propulsion.propellantMass).toFixed(2)
  );

  // 6. ADCS
  const sensorMass = design.adcs.sensors.length * 0.08;
  let actuatorMass = 0.1; // Magnetorquers
  if (design.adcs.actuators.includes('reaction-wheel')) actuatorMass += 0.45;
  if (design.adcs.actuators.includes('momentum-wheel')) actuatorMass += 0.6;
  const adcs = Number((sensorMass + actuatorMass).toFixed(2));

  // 7. Onboard Computer (OBC)
  let computerMass = 0.12;
  if (design.onboardComputer === 'standard') computerMass = 0.2;
  if (design.onboardComputer === 'high-performance') computerMass = 0.35;
  const computer = Number(computerMass.toFixed(2));

  // 8. Payload (Instruments & Optics)
  const selectedInsts = INSTRUMENTS.filter((i) => design.instruments.includes(i.id));
  const selectedOptics = OPTICS.filter((o) => design.optics.includes(o.id));

  const instMass = selectedInsts.reduce((sum, i) => sum + i.mass, 0);
  const opticsMass = selectedOptics.reduce((sum, o) => sum + o.mass, 0);
  const payload = Number((instMass + opticsMass).toFixed(2));

  // 9. Harness & Cabling (typically ~5% of dry mass)
  const drySubtotal =
    structure + power + comms + thermal + propulsion + adcs + computer + payload;
  const harness = Number((drySubtotal * 0.05).toFixed(2));

  // Total Mass
  const totalMass = Number((drySubtotal + harness).toFixed(2));

  // Margin (%)
  const margin = Number((((maxMass - totalMass) / maxMass) * 100).toFixed(1));

  // Status & Details
  let status: 'ok' | 'warning' | 'critical' = 'ok';
  const details: string[] = [];

  if (totalMass > maxMass) {
    status = 'critical';
    details.push(
      `Mass limit exceeded: ${totalMass} kg exceeds ${maxMass} kg limit for ${design.size} CubeSat deployer standard.`
    );
  } else if (margin < 15.0) {
    status = 'warning';
    details.push(
      `Tight mass margin (${margin}%). Flight readiness requires at least 15% mass reserve.`
    );
  } else {
    details.push(`Healthy mass margin (${margin}%). Within all deployer launch constraints.`);
  }

  return {
    structure,
    power,
    comms,
    thermal,
    propulsion,
    adcs,
    computer,
    payload,
    harness,
    totalMass,
    maxMass,
    margin,
    status,
    details,
  };
}
