// ============================================================================
// CubeSat Mission Designer — Power Budget Engine
// ============================================================================

import type { CubeSatDesign, OrbitParameters, PowerBudgetResult } from '../../types';
import { INSTRUMENTS } from '../../data/instruments';
import { sizeToUnits } from '../../data/compatibility';

/**
 * Solar constant at 1 AU (W/m²)
 */
const SOLAR_CONSTANT = 1361;

/**
 * Calculates Electrical Power System (EPS) budget, solar generation, and battery margins.
 */
export function calculatePowerBudget(
  design: CubeSatDesign,
  orbit: OrbitParameters
): PowerBudgetResult {
  const units = sizeToUnits(design.size);

  // 1. Calculate Solar Array Area (m²)
  // 1U face = 0.1m x 0.1m = 0.01 m²
  let panelArea = 0;
  if (design.power.solarPanelType === 'body-mounted') {
    // Roughly 2 long faces illuminated at best angle: 2 * (units * 0.01 m²)
    panelArea = units * 0.01 * 1.5;
  } else if (design.power.solarPanelType === 'deployable-fixed') {
    // 2 deployable wings plus body
    panelArea = (units * 0.01) * 3.5;
  } else {
    // 'deployable-tracking' — 2 tracking wings with near-normal incidence
    panelArea = (units * 0.01) * 4.2;
  }

  // 2. Cell Efficiency
  let cellEff = 0.3; // Triple-junction
  if (design.power.solarCellType === 'silicon') {
    cellEff = 0.17;
  } else if (design.power.solarCellType === 'perovskite') {
    cellEff = 0.22;
  }

  // Accounting for packing factor, glass cover losses, assembly factor (~0.85)
  const effectiveArea = panelArea * 0.85;

  // Power generated in full sunlight (W)
  // Incidence cosine factor average ~0.85 for tracking, ~0.65 for fixed
  const sunAngleFactor =
    design.power.solarPanelType === 'deployable-tracking' ? 0.9 : 0.7;

  // Solar array degradation over mission life (e.g. 2.5% per year)
  const degradation = Math.pow(0.975, design.missionDuration / 12);

  const powerGeneratedSunlit =
    effectiveArea * SOLAR_CONSTANT * cellEff * sunAngleFactor * degradation;

  // 3. Orbit Day / Night Timing (minutes)
  const period = orbit.period; // minutes
  const eclipseDuration = period * orbit.eclipseFraction;
  const sunlitDuration = period - eclipseDuration;

  // Orbit average power generation
  const powerGenerated =
    period > 0 ? (powerGeneratedSunlit * sunlitDuration) / period : powerGeneratedSunlit;

  // 4. Power Demands (W)
  // Payload power from equipped instruments
  const selectedInsts = INSTRUMENTS.filter((i) => design.instruments.includes(i.id));
  const payloadPower = selectedInsts.reduce((sum, inst) => sum + inst.power, 0);

  // Bus baseline power:
  // Onboard Computer: basic ~1.5W, standard ~3W, high-performance ~6W
  let obcPower = 3.0;
  if (design.onboardComputer === 'basic') obcPower = 1.5;
  if (design.onboardComputer === 'high-performance') obcPower = 6.0;

  // ADCS: magnetorquer + reaction wheels + sensors
  const adcsPower =
    design.adcs.sensors.length * 0.4 + design.adcs.actuators.length * 1.5;

  // Comms: baseline receiver + duty-cycled transmitter
  // transmitter duty cycle ~15% of orbit
  const commsPower = 1.0 + design.comms.transmitPower * 0.4;

  // Thermal: heaters if enabled
  const thermalPower = design.thermal.heaters ? 2.5 : 0.0;

  const subsystemPower = obcPower + adcsPower + commsPower + thermalPower;
  const totalPowerRequired = payloadPower + subsystemPower;

  // 5. Battery Analysis (Depth of Discharge - DOD)
  // Energy required during eclipse (Wh) = totalPowerRequired * (eclipseDuration / 60 hours)
  const eclipseEnergyNeeded = totalPowerRequired * (eclipseDuration / 60);
  const batteryCapacity = design.power.batteryCapacity; // Wh

  const batteryDepthOfDischarge =
    batteryCapacity > 0
      ? Math.min(100, Math.round((eclipseEnergyNeeded / batteryCapacity) * 100))
      : 100;

  // Estimated life cycles based on DOD:
  // For Li-ion: 20% DOD ~ 10,000 cycles, 40% DOD ~ 4,000 cycles, 80% DOD ~ 800 cycles
  let batteryLifeCycles = 8000;
  if (batteryDepthOfDischarge > 60) batteryLifeCycles = 1200;
  else if (batteryDepthOfDischarge > 40) batteryLifeCycles = 3500;
  else if (batteryDepthOfDischarge > 25) batteryLifeCycles = 6000;

  // 6. Power Margin (%)
  const margin =
    totalPowerRequired > 0
      ? Math.round(((powerGenerated - totalPowerRequired) / totalPowerRequired) * 100)
      : 0;

  // 7. Status & Details
  let status: 'ok' | 'warning' | 'critical' = 'ok';
  const details: string[] = [];

  if (margin < 0) {
    status = 'critical';
    details.push('Power deficit: solar generation cannot sustain satellite power draw.');
  } else if (margin < 20) {
    status = 'warning';
    details.push('Low power margin (< 20%). NASA guidelines recommend at least 25% margin at PDR.');
  } else {
    details.push('Nominal power margin (> 20%). Generation meets all subsystem demands.');
  }

  if (batteryDepthOfDischarge > 50) {
    if (status !== 'critical') status = 'warning';
    details.push(
      `High battery DOD (${batteryDepthOfDischarge}%). Battery cell degradation will accelerate in eclipse.`
    );
  }

  return {
    solarPanelArea: Number(panelArea.toFixed(3)),
    powerGenerated: Number(powerGenerated.toFixed(1)),
    powerGeneratedSunlit: Number(powerGeneratedSunlit.toFixed(1)),
    totalPowerRequired: Number(totalPowerRequired.toFixed(1)),
    payloadPower: Number(payloadPower.toFixed(1)),
    subsystemPower: Number(subsystemPower.toFixed(1)),
    eclipseDuration: Number(eclipseDuration.toFixed(1)),
    sunlitDuration: Number(sunlitDuration.toFixed(1)),
    batteryDepthOfDischarge,
    batteryLifeCycles,
    margin,
    status,
    details,
  };
}
