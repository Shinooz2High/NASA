// ============================================================================
// CubeSat Mission Designer — Propulsion & Orbital Maneuvers Engine
// ============================================================================

import type { CubeSatDesign, PropulsionResult } from '../../types';
import { sizeToUnits } from '../../data/compatibility';

const G0 = 9.80665; // m/s²

export function calculatePropulsion(design: CubeSatDesign): PropulsionResult {
  const units = sizeToUnits(design.size);
  const wetMass = units * 1.5; // Approx baseline wet mass
  const propMass = design.propulsion.propellantMass;
  const dryMass = Math.max(0.5, wetMass - propMass);

  if (design.propulsion.type === 'none' || propMass <= 0) {
    return {
      totalDeltaV: 0,
      specificImpulse: 0,
      thrustLevel: 0,
      propellantMass: 0,
      burnTime: 0,
      maneuverCapability: [
        'Natural orbital decay only (no active orbital control)',
        'Subject to atmospheric drag lifetime constraints',
      ],
      status: 'ok',
    };
  }

  let isp = 70; // s
  let thrustMn = 50; // mN

  switch (design.propulsion.type) {
    case 'cold-gas':
      isp = 70;
      thrustMn = 50;
      break;
    case 'resistojet':
      isp = 150;
      thrustMn = 100;
      break;
    case 'ion':
      isp = 3000;
      thrustMn = 2.5; // Micro-propulsion
      break;
    case 'hall-effect':
      isp = 1500;
      thrustMn = 12.0;
      break;
  }

  // Tsiolkovsky rocket equation: ΔV = Isp * g0 * ln(m0 / mf)
  const totalDeltaV = Number((isp * G0 * Math.log(wetMass / dryMass)).toFixed(1));

  // Burn time (s) = (m_prop * Isp * g0) / Thrust
  const thrustNewtons = thrustMn / 1000;
  const burnTime = Math.round((propMass * isp * G0) / thrustNewtons);

  // Maneuver capabilities
  const maneuverCapability: string[] = [];
  if (totalDeltaV >= 20) {
    maneuverCapability.push('Collision avoidance maneuvers against orbital debris');
  }
  if (totalDeltaV >= 50) {
    maneuverCapability.push('Atmospheric drag compensation & altitude maintenance');
  }
  if (totalDeltaV >= 100) {
    maneuverCapability.push('Controlled de-orbit at End-of-Life (compliant with NASA 5-year rule)');
  }
  if (totalDeltaV >= 250) {
    maneuverCapability.push('Significant orbital plane change or orbit raising');
  }
  if (totalDeltaV >= 500) {
    maneuverCapability.push('Lunar transfer or interplanetary trajectory correction maneuvers');
  }

  let status: 'ok' | 'warning' | 'critical' = 'ok';
  if (totalDeltaV < 15) {
    status = 'warning';
    maneuverCapability.push('Very low delta-V budget; limited to minimal momentum dumping');
  }

  return {
    totalDeltaV,
    specificImpulse: isp,
    thrustLevel: thrustMn,
    propellantMass: propMass,
    burnTime,
    maneuverCapability,
    status,
  };
}
