// ============================================================================
// CubeSat Mission Designer — Thermal Equilibrium Engine
// ============================================================================

import type { CubeSatDesign, OrbitParameters, ThermalResult } from '../../types';
import { sizeToUnits } from '../../data/compatibility';

/**
 * Stefan-Boltzmann constant (W / (m² · K⁴))
 */
const STEFAN_BOLTZMANN = 5.670374e-8;

/**
 * Solar constant (W/m²)
 */
const SOLAR_FLUX = 1361;

export function calculateThermalBalance(
  design: CubeSatDesign,
  orbit: OrbitParameters
): ThermalResult {
  const units = sizeToUnits(design.size);

  // Surface areas (m²)
  // 1U face = 0.01 m²
  // Total surface area of a rectangular prism of N units (10cm x 10cm x (N*10cm))
  const surfaceArea = 2 * (0.01) + 4 * (0.01 * units);
  const projectedSunArea = 0.01 * units * 1.2;

  // Optical coating properties:
  // Solar absorptivity (alpha) and IR emissivity (epsilon)
  let alpha = 0.65; // Black anodized / solar cell mix
  let epsilon = 0.8;

  if (design.thermal.mli) {
    // Multi-layer insulation blanket reduces radiative exchange
    epsilon = 0.15;
    alpha = 0.25;
  }

  // Radiators increase effective radiating surface in high emissivity
  const radiatorArea = design.thermal.radiators ? 0.01 * units * 0.8 : 0.0;
  const effectiveRadArea = surfaceArea + radiatorArea * 2.0;

  // Internal dissipation (W)
  // Average heat dissipation from electronics ~80% of electrical power
  const internalHeat = units * 3.5;

  // 1. Hot Case (direct sun + Earth IR/Albedo + max internal power)
  // Earth IR in LEO ~237 W/m², albedo factor ~0.3
  const isNearEarth = orbit.altitude < 2000;
  const earthIrFlux = isNearEarth ? 230 * (0.01 * units) : 0;
  const albedoFlux = isNearEarth ? SOLAR_FLUX * 0.3 * (0.01 * units * 0.6) : 0;

  const qSolarAbsorbed = alpha * SOLAR_FLUX * projectedSunArea;
  const qHotTotal = qSolarAbsorbed + earthIrFlux + albedoFlux + internalHeat;

  // T_hot^4 = Q_hot / (epsilon * sigma * A_rad)
  const tHotKelvin = Math.pow(
    qHotTotal / (epsilon * STEFAN_BOLTZMANN * effectiveRadArea),
    0.25
  );
  const hotCaseTemp = Math.round(tHotKelvin - 273.15);

  // 2. Cold Case (eclipse, no sun, no albedo, standby electronics)
  let heaterPower = 0.0;
  const standbyHeat = internalHeat * 0.3; // Standby dissipation

  // In eclipse, only internal heat (and earth IR if near earth)
  const qColdBase = (isNearEarth ? earthIrFlux * 0.8 : 0) + standbyHeat;

  let tColdKelvin = Math.pow(
    Math.max(1.0, qColdBase) / (epsilon * STEFAN_BOLTZMANN * effectiveRadArea),
    0.25
  );
  let coldCaseTemp = Math.round(tColdKelvin - 273.15);

  // If heaters are active and cold case drops below 0°C, apply heat
  if (design.thermal.heaters && coldCaseTemp < 0) {
    heaterPower = 3.5; // W
    const qWithHeater = qColdBase + heaterPower;
    tColdKelvin = Math.pow(
      qWithHeater / (epsilon * STEFAN_BOLTZMANN * effectiveRadArea),
      0.25
    );
    coldCaseTemp = Math.round(tColdKelvin - 273.15);
  }

  const averageTemp = Math.round((hotCaseTemp + coldCaseTemp) / 2);

  // Standard aerospace operating range for industrial electronics: -20°C to +50°C
  const operatingRange = { min: -20, max: 55 };
  const withinLimits =
    coldCaseTemp >= operatingRange.min && hotCaseTemp <= operatingRange.max;

  // Status & Details
  let status: 'ok' | 'warning' | 'critical' = 'ok';
  const details: string[] = [];

  if (hotCaseTemp > operatingRange.max + 15 || coldCaseTemp < operatingRange.min - 15) {
    status = 'critical';
    details.push(
      `Extreme thermal excursion (Hot: ${hotCaseTemp}°C, Cold: ${coldCaseTemp}°C). Electronics or batteries will suffer permanent damage.`
    );
  } else if (!withinLimits) {
    status = 'warning';
    details.push(
      `Temperature exceeds nominal limits [${operatingRange.min}°C to ${operatingRange.max}°C]. Recommend MLI insulation, radiator panels, or active heaters.`
    );
  } else {
    details.push('Thermal equilibrium within nominal operational bounds.');
  }

  return {
    hotCaseTemp,
    coldCaseTemp,
    averageTemp,
    solarAbsorbed: Number(qSolarAbsorbed.toFixed(1)),
    irEmitted: Number(qHotTotal.toFixed(1)),
    internalHeat: Number(internalHeat.toFixed(1)),
    heaterPower,
    operatingRange,
    withinLimits,
    status,
    details,
  };
}
