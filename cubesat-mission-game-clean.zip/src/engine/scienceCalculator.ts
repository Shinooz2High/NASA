// ============================================================================
// CubeSat Mission Designer — Science Return & Discovery Calculator
// ============================================================================

import type { CubeSatDesign, PointDesignResult, ScienceResult } from '../types';
import { OBJECTIVES } from '../data/objectives';
import { INSTRUMENTS } from '../data/instruments';

export function calculateScienceResults(
  design: CubeSatDesign,
  pointDesign: PointDesignResult
): ScienceResult {
  const selectedObjs = OBJECTIVES.filter((o) => design.objectives.includes(o.id));
  const selectedInsts = INSTRUMENTS.filter((i) => design.instruments.includes(i.id));

  // 1. Instrument duty cycle allowed by power margin
  let dutyCycle = 85;
  if (pointDesign.power.margin < 0) dutyCycle = 15;
  else if (pointDesign.power.margin < 15) dutyCycle = 45;
  else if (pointDesign.power.margin > 35) dutyCycle = 95;

  // 2. Data volume: minimum of payload generation vs comms downlink bottleneck
  const rawDataGenMbPerDay =
    selectedInsts.reduce((sum, i) => sum + i.dataRate * 3600 * (dutyCycle / 100), 0) / 8;
  const downlinkCapacityMbPerDay = pointDesign.link.dailyDataVolume;

  const dataCollectedPerDay = Math.min(
    Math.round(rawDataGenMbPerDay),
    Math.round(downlinkCapacityMbPerDay)
  );

  // 3. Operational lifetime (months)
  let missionLifetime = design.missionDuration;
  if (pointDesign.power.batteryDepthOfDischarge > 60) {
    missionLifetime = Math.max(3, Math.round(missionLifetime * 0.5));
  }
  if (!pointDesign.thermal.withinLimits) {
    missionLifetime = Math.max(2, Math.round(missionLifetime * 0.6));
  }

  const totalDataMission = Number(
    ((dataCollectedPerDay * missionLifetime * 30.5) / 1024).toFixed(1)
  );

  // 4. Observational coverage (%)
  let coverage = 70;
  if (design.orbit === 'SSO') coverage = 92;
  else if (design.orbit === 'LEO') coverage = 65;
  else if (design.orbit === 'GEO') coverage = 35; // Stares at one hemisphere
  else if (design.orbit === 'lunar') coverage = 88;
  else if (design.orbit === 'L1' || design.orbit === 'L2') coverage = 99;

  // 5. Overall Science Score (0-100)
  let scienceScore = 50;

  // Objective fulfillment
  selectedObjs.forEach((obj) => {
    const hasMatchingWavelength = obj.compatibleWavelengths.some((w) =>
      design.wavelengths.includes(w)
    );
    if (hasMatchingWavelength) scienceScore += 15;
  });

  // Instrument diversity
  scienceScore += Math.min(20, selectedInsts.length * 10);

  // Feasibility penalty factor
  const feasibilityFactor = pointDesign.feasibilityScore / 100;
  scienceScore = Math.round(
    Math.max(10, Math.min(100, scienceScore * feasibilityFactor))
  );

  // 6. Discoveries narrative generated from objectives
  const discoveries: ScienceResult['discoveries'] = [];

  selectedObjs.forEach((obj) => {
    switch (obj.id) {
      case 'climate-monitoring':
      case 'obj-climate-monitoring':
        discoveries.push({
          title: {
            en: 'High-Resolution Methane Plume Mapping Published in Nature',
            vi: 'Bản đồ Điểm phát thải Khí Methane độ nét cao đăng trên tạp chí Nature',
          },
          description: {
            en: 'Pinpointed 14 previously undocumented industrial fugitive methane leaks with 98% localized precision.',
            vi: 'Xác định chính xác 14 điểm rò rỉ khí methane công nghiệp chưa từng được ghi nhận với độ chuẩn 98%.',
          },
          probability: 0.94,
        });
        break;

      case 'ocean-color':
      case 'obj-ocean-color':
        discoveries.push({
          title: {
            en: 'Harmful Coastal Algal Bloom Early Warning Alert Triggered',
            vi: 'Phát tín hiệu Cảnh báo Sớm Hiện tượng Thủy triều Đỏ Tảo độc Ven biển',
          },
          description: {
            en: 'Detected toxic dinoflagellate chlorophyll concentration surge 5 days before shore contamination.',
            vi: 'Phát hiện nồng độ diệp lục tố tảo độc bùng phát 5 ngày trước khi tràn vào bờ biển nuôi trồng thủy sản.',
          },
          probability: 0.89,
        });
        break;

      case 'exoplanet-transit':
      case 'obj-exoplanet-transit':
        discoveries.push({
          title: {
            en: 'Candidate Sub-Neptune Exoplanet Confirmed via Precision Photometry',
            vi: 'Xác nhận Ứng viên Hành tinh Ngoại hệ Cận Hải Vương qua Trắc quang Chính xác',
          },
          description: {
            en: 'Measured 0.08% transit dip around bright K-dwarf star HD-140283 with high signal-to-noise ratio.',
            vi: 'Ghi nhận hiện tượng che khuất độ sáng 0.08% quanh ngôi sao lùn K sáng HD-140283 với tỷ số tín hiệu cao.',
          },
          probability: 0.82,
        });
        break;

      case 'solar-flares':
      case 'obj-solar-flares':
        discoveries.push({
          title: {
            en: 'Fast X-ray Magnetic Reconnection Precursor Preceding X-Class Flare Detected',
            vi: 'Ghi nhận Tiền chất Tái kết nối Từ trường Tia X trước Vụ nổ Mặt trời Cực đại X-Class',
          },
          description: {
            en: 'Provided 32-minute advance alert to satellite operators prior to geomagnetic storm arrival.',
            vi: 'Cung cấp cảnh báo sớm 32 phút cho các nhà vận hành vệ tinh trước khi bão địa từ ập vào Trái đất.',
          },
          probability: 0.96,
        });
        break;

      case 'lunar-volatiles':
      case 'obj-lunar-volatiles':
        discoveries.push({
          title: {
            en: 'Subsurface Water Ice Concentration Confirmed in Shackleton Crater Rim',
            vi: 'Xác nhận Băng Nước Ngầm tại Vành Miệng Núi lửa Shackleton ở Cực Nam Mặt trăng',
          },
          description: {
            en: 'Neutron absorption signature confirmed estimated 5.5 wt% water-equivalent hydrogen deposits.',
            vi: 'Dấu hiệu hấp thụ neutron xác nhận nồng độ hydro tương đương nước ước đạt 5.5% trọng lượng trầm tích.',
          },
          probability: 0.88,
        });
        break;

      default:
        discoveries.push({
          title: {
            en: `Peer-Reviewed Breakthrough in ${obj.name.en}`,
            vi: `Đột phá Khoa học Đăng tải Bình duyệt về ${obj.name.vi}`,
          },
          description: {
            en: `Mission datasets successfully delivered to NASA Planetary Data System (PDS) archive with 99.2% integrity.`,
            vi: `Dữ liệu nhiệm vụ đã được chuyển nạp vào kho lưu trữ Hệ thống Dữ liệu Hành tinh của NASA (PDS) với độ toàn vẹn 99.2%.`,
          },
          probability: 0.85,
        });
        break;
    }
  });

  return {
    scienceScore,
    dataCollectedPerDay,
    totalDataMission,
    missionLifetime,
    coverage,
    dutyCycle,
    discoveries,
  };
}
