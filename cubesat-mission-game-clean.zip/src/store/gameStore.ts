// ============================================================================
// CubeSat Mission Designer — Zustand Game Store
// ============================================================================

import { create } from 'zustand';
import type {
  CubeSatDesign,
  GameLevel,
  GameScreen,
  MissionMatchResult,
  PointDesignResult,
  ScienceResult,
} from '../types';
import { createDefaultDesign } from '../types/design';
import { calculatePointDesign } from '../engine/pointDesign';
import { calculateScienceResults } from '../engine/scienceCalculator';
import { findMatchingMissions } from '../engine/missionMatcher';

const SCREEN_ORDER: GameScreen[] = [
  'start',
  'level-select',
  'objective-select',
  'wavelength-select',
  'instrument-select',
  'optics-select',
  'size-select',
  'orbit-select',
  'subsystem-design',
  'point-design',
  'launch',
  'results',
  'nasa-match',
];

interface GameState {
  level: GameLevel;
  currentScreen: GameScreen;
  design: CubeSatDesign;
  pointDesignResult: PointDesignResult | null;
  scienceResult: ScienceResult | null;
  matchResults: MissionMatchResult[];

  // Actions
  setLevel: (level: GameLevel) => void;
  setScreen: (screen: GameScreen) => void;
  updateDesign: (updates: Partial<CubeSatDesign>) => void;
  setDesign: (design: CubeSatDesign) => void;
  setPointDesignResult: (res: PointDesignResult | null) => void;
  setScienceResult: (res: ScienceResult | null) => void;
  setMatchResults: (res: MissionMatchResult[]) => void;

  runPointDesign: () => PointDesignResult;
  runMissionCompletion: () => void;
  nextScreen: () => void;
  prevScreen: () => void;
  resetGame: () => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  level: 1,
  currentScreen: 'start',
  design: createDefaultDesign(),
  pointDesignResult: null,
  scienceResult: null,
  matchResults: [],

  setLevel: (level) => {
    set((state) => {
      // In level 1, size is fixed to 3U
      const newSize = level === 1 ? '3U' : state.design.size;
      return {
        level,
        design: { ...state.design, size: newSize },
      };
    });
  },

  setScreen: (currentScreen) => set({ currentScreen }),

  updateDesign: (updates) =>
    set((state) => ({
      design: { ...state.design, ...updates },
    })),

  setDesign: (design) => set({ design }),

  setPointDesignResult: (pointDesignResult) => set({ pointDesignResult }),
  setScienceResult: (scienceResult) => set({ scienceResult }),
  setMatchResults: (matchResults) => set({ matchResults }),

  runPointDesign: () => {
    const { design } = get();
    const result = calculatePointDesign(design);
    set({ pointDesignResult: result });
    return result;
  },

  runMissionCompletion: () => {
    const { design } = get();
    const pointDesign = calculatePointDesign(design);
    const science = calculateScienceResults(design, pointDesign);
    const matches = findMatchingMissions(design, 3);

    set({
      pointDesignResult: pointDesign,
      scienceResult: science,
      matchResults: matches,
    });
  },

  nextScreen: () => {
    const { currentScreen, level } = get();
    const currentIndex = SCREEN_ORDER.indexOf(currentScreen);

    if (currentIndex >= 0 && currentIndex < SCREEN_ORDER.length - 1) {
      let nextIndex = currentIndex + 1;

      // In Level 1: skip optics-select, size-select, and subsystem-design for a streamlined experience!
      if (level === 1) {
        if (currentScreen === 'instrument-select') {
          nextIndex = SCREEN_ORDER.indexOf('orbit-select');
        } else if (currentScreen === 'orbit-select') {
          nextIndex = SCREEN_ORDER.indexOf('point-design');
        }
      }

      const nextScreen = SCREEN_ORDER[nextIndex];

      // Auto-trigger calculation when entering point-design or launch
      if (nextScreen === 'point-design') {
        get().runPointDesign();
      } else if (nextScreen === 'results') {
        get().runMissionCompletion();
      }

      set({ currentScreen: nextScreen });
    }
  },

  prevScreen: () => {
    const { currentScreen, level } = get();
    const currentIndex = SCREEN_ORDER.indexOf(currentScreen);

    if (currentIndex > 0) {
      let prevIndex = currentIndex - 1;

      // In Level 1 reverse jumps
      if (level === 1) {
        if (currentScreen === 'point-design') {
          prevIndex = SCREEN_ORDER.indexOf('orbit-select');
        } else if (currentScreen === 'orbit-select') {
          prevIndex = SCREEN_ORDER.indexOf('instrument-select');
        }
      }

      set({ currentScreen: SCREEN_ORDER[prevIndex] });
    }
  },

  resetGame: () =>
    set({
      currentScreen: 'start',
      design: createDefaultDesign(),
      pointDesignResult: null,
      scienceResult: null,
      matchResults: [],
    }),
}));
