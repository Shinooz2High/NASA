// ============================================================================
// CubeSat Mission Designer — Save & Load Manager (localStorage)
// ============================================================================

import type { CubeSatDesign } from '../types';

const STORAGE_KEY = 'cubesat_mission_designs';

export function loadSavedDesigns(): CubeSatDesign[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to load saved designs from localStorage:', err);
    return [];
  }
}

export function saveDesignToStorage(design: CubeSatDesign): boolean {
  try {
    const designs = loadSavedDesigns();
    const existingIndex = designs.findIndex((d) => d.id === design.id);
    if (existingIndex >= 0) {
      designs[existingIndex] = { ...design, createdAt: Date.now() };
    } else {
      designs.unshift({ ...design, createdAt: Date.now() });
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(designs));
    return true;
  } catch (err) {
    console.error('Failed to save design to localStorage:', err);
    return false;
  }
}

export function deleteSavedDesign(id: string): boolean {
  try {
    const designs = loadSavedDesigns().filter((d) => d.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(designs));
    return true;
  } catch (err) {
    console.error('Failed to delete design:', err);
    return false;
  }
}

export function exportDesignAsJson(design: CubeSatDesign): string {
  return JSON.stringify(design, null, 2);
}

export function importDesignFromJson(jsonString: string): CubeSatDesign | null {
  try {
    const parsed = JSON.parse(jsonString);
    if (!parsed.id || !parsed.size || !parsed.power) {
      throw new Error('Invalid CubeSat design JSON structure');
    }
    return parsed as CubeSatDesign;
  } catch (err) {
    console.error('Failed to import design JSON:', err);
    return null;
  }
}
