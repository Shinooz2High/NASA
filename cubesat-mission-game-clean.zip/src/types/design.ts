// ============================================================================
// CubeSat Mission Designer — Design Types
// ============================================================================

import type { CubeSatSize, OrbitType, WavelengthBand } from './mission';

export interface PowerSubsystem {
  solarPanelType: 'body-mounted' | 'deployable-fixed' | 'deployable-tracking';
  solarCellType: 'silicon' | 'triple-junction' | 'perovskite';
  batteryType: 'li-ion' | 'li-po';
  batteryCapacity: number; // Wh
}

export interface CommsSubsystem {
  frequency: 'UHF' | 'S-band' | 'X-band' | 'Ka-band';
  antennaType: 'dipole' | 'patch' | 'horn' | 'parabolic' | 'phased-array';
  transmitPower: number; // W
}

export interface ThermalSubsystem {
  type: 'passive' | 'semi-active' | 'active';
  heaters: boolean;
  radiators: boolean;
  mli: boolean;
}

export interface PropulsionSubsystem {
  type: 'none' | 'cold-gas' | 'resistojet' | 'ion' | 'hall-effect';
  propellantMass: number; // kg
}

export interface ADCSSubsystem {
  sensors: ('sun-sensor' | 'magnetometer' | 'star-tracker' | 'gyroscope')[];
  actuators: ('magnetorquer' | 'reaction-wheel' | 'momentum-wheel')[];
}

export interface CubeSatDesign {
  id: string;
  name: string;
  size: CubeSatSize;
  objectives: string[];
  wavelengths: WavelengthBand[];
  instruments: string[];
  optics: string[];
  orbit: OrbitType;
  orbitAltitude: number; // km
  power: PowerSubsystem;
  comms: CommsSubsystem;
  thermal: ThermalSubsystem;
  propulsion: PropulsionSubsystem;
  adcs: ADCSSubsystem;
  onboardComputer: 'basic' | 'standard' | 'high-performance';
  missionDuration: number; // months
  createdAt: number;
}

export const DEFAULT_POWER: PowerSubsystem = {
  solarPanelType: 'body-mounted',
  solarCellType: 'triple-junction',
  batteryType: 'li-ion',
  batteryCapacity: 40,
};

export const DEFAULT_COMMS: CommsSubsystem = {
  frequency: 'UHF',
  antennaType: 'dipole',
  transmitPower: 2,
};

export const DEFAULT_THERMAL: ThermalSubsystem = {
  type: 'passive',
  heaters: false,
  radiators: false,
  mli: true,
};

export const DEFAULT_PROPULSION: PropulsionSubsystem = {
  type: 'none',
  propellantMass: 0,
};

export const DEFAULT_ADCS: ADCSSubsystem = {
  sensors: ['sun-sensor', 'magnetometer'],
  actuators: ['magnetorquer'],
};

export function createDefaultDesign(): CubeSatDesign {
  return {
    id: crypto.randomUUID(),
    name: '',
    size: '3U',
    objectives: [],
    wavelengths: [],
    instruments: [],
    optics: [],
    orbit: 'LEO',
    orbitAltitude: 500,
    power: { ...DEFAULT_POWER },
    comms: { ...DEFAULT_COMMS },
    thermal: { ...DEFAULT_THERMAL },
    propulsion: { ...DEFAULT_PROPULSION },
    adcs: { ...DEFAULT_ADCS },
    onboardComputer: 'standard',
    missionDuration: 12,
    createdAt: Date.now(),
  };
}
