// ============================================================================
// CubeSat Mission Designer — Mission Types
// ============================================================================

export type ScientificDomain =
  | 'earth-observation'
  | 'astrophysics'
  | 'heliophysics'
  | 'planetary-science'
  | 'technology-demo';

export type WavelengthBand =
  | 'radio'
  | 'microwave'
  | 'infrared'
  | 'visible'
  | 'ultraviolet'
  | 'x-ray'
  | 'gamma-ray';

export type OrbitType =
  | 'LEO'
  | 'SSO'
  | 'MEO'
  | 'GEO'
  | 'HEO'
  | 'lunar'
  | 'L1'
  | 'L2'
  | 'interplanetary';

export interface ScientificObjective {
  id: string;
  domain: ScientificDomain;
  name: { en: string; vi: string };
  description: { en: string; vi: string };
  icon: string;
  compatibleWavelengths: WavelengthBand[];
  suggestedOrbits: OrbitType[];
  difficulty: 1 | 2 | 3;
}

export interface Wavelength {
  id: WavelengthBand;
  name: { en: string; vi: string };
  description: { en: string; vi: string };
  range: string;
  color: string; // CSS color for UI
  compatibleInstruments: string[];
}

export interface Instrument {
  id: string;
  name: { en: string; vi: string };
  description: { en: string; vi: string };
  type:
    | 'camera'
    | 'spectrometer'
    | 'magnetometer'
    | 'particle-detector'
    | 'radio-receiver'
    | 'radar'
    | 'lidar';
  mass: number; // kg
  power: number; // W
  dataRate: number; // Mbps
  volume: number; // U (CubeSat units)
  compatibleWavelengths: WavelengthBand[];
  compatibleOptics: string[];
  minSize: CubeSatSize;
  icon: string;
}

export interface OpticalSystem {
  id: string;
  name: { en: string; vi: string };
  description: { en: string; vi: string };
  type:
    | 'reflector'
    | 'refractor'
    | 'antenna-dish'
    | 'phased-array'
    | 'deployable-boom';
  aperture: number; // m
  mass: number; // kg
  fov: number; // degrees
  volume: number; // U
  compatibleWavelengths: WavelengthBand[];
  minSize: CubeSatSize;
}

export type CubeSatSize = '1U' | '2U' | '3U' | '6U' | '12U';

export interface OrbitParameters {
  type: OrbitType;
  altitude: number; // km
  inclination: number; // degrees
  eccentricity: number;
  period: number; // minutes
  eclipseFraction: number; // 0-1
  name: { en: string; vi: string };
  description: { en: string; vi: string };
}

export interface NasaMission {
  id: string;
  name: string;
  description: { en: string; vi: string };
  launchYear: number;
  status: 'active' | 'completed' | 'planned';
  objectives: ScientificDomain[];
  wavelengths: WavelengthBand[];
  instrumentTypes: string[];
  orbit: OrbitType;
  orbitAltitude?: number;
  mass: number; // kg
  imageUrl: string;
  nasaUrl: string;
  matchTags: string[];
  isCubesat: boolean;
}

export type GameLevel = 1 | 2 | 3;

export type GameScreen =
  | 'start'
  | 'level-select'
  | 'objective-select'
  | 'wavelength-select'
  | 'instrument-select'
  | 'optics-select'
  | 'size-select'
  | 'orbit-select'
  | 'subsystem-design'
  | 'point-design'
  | 'launch'
  | 'results'
  | 'nasa-match';
