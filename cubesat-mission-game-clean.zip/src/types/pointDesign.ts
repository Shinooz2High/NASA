// ============================================================================
// CubeSat Mission Designer — Point Design Types
// ============================================================================

export interface PowerBudgetResult {
  solarPanelArea: number;         // m²
  powerGenerated: number;          // W (orbit average)
  powerGeneratedSunlit: number;    // W (sunlit only)
  totalPowerRequired: number;      // W
  payloadPower: number;            // W
  subsystemPower: number;          // W
  eclipseDuration: number;         // minutes
  sunlitDuration: number;          // minutes
  batteryDepthOfDischarge: number; // %
  batteryLifeCycles: number;
  margin: number;                  // %
  status: 'ok' | 'warning' | 'critical';
  details: string[];
}

export interface LinkBudgetResult {
  eirp: number;               // dBW
  pathLoss: number;            // dB
  atmosphericLoss: number;     // dB
  receivedPower: number;       // dBW
  noiseTemperature: number;    // K
  snr: number;                 // dB
  requiredSnr: number;         // dB
  dataRate: number;            // kbps achievable
  contactTimePerOrbit: number; // minutes
  orbitsPerDay: number;
  contactsPerDay: number;
  dailyDataVolume: number;     // MB
  margin: number;              // dB
  status: 'ok' | 'warning' | 'critical';
  details: string[];
}

export interface ThermalResult {
  hotCaseTemp: number;        // °C
  coldCaseTemp: number;       // °C
  averageTemp: number;        // °C
  solarAbsorbed: number;      // W
  irEmitted: number;          // W
  internalHeat: number;       // W
  heaterPower: number;        // W needed
  operatingRange: { min: number; max: number }; // °C
  withinLimits: boolean;
  status: 'ok' | 'warning' | 'critical';
  details: string[];
}

export interface MassBudgetResult {
  structure: number;     // kg
  power: number;         // kg
  comms: number;         // kg
  thermal: number;       // kg
  propulsion: number;    // kg
  adcs: number;          // kg
  computer: number;      // kg
  payload: number;       // kg
  harness: number;       // kg
  totalMass: number;     // kg
  maxMass: number;       // kg
  margin: number;        // %
  status: 'ok' | 'warning' | 'critical';
  details: string[];
}

export interface PropulsionResult {
  totalDeltaV: number;      // m/s
  specificImpulse: number;  // s
  thrustLevel: number;      // mN
  propellantMass: number;   // kg
  burnTime: number;         // s
  maneuverCapability: string[];
  status: 'ok' | 'warning' | 'critical';
}

export interface CostEstimateResult {
  hardware: number;       // USD
  software: number;       // USD
  integration: number;    // USD
  testing: number;        // USD
  launchCost: number;     // USD
  operations: number;     // USD
  totalCost: number;      // USD
  costPerKg: number;      // USD/kg
  costCategory: 'low' | 'medium' | 'high' | 'very-high';
}

export interface PointDesignResult {
  power: PowerBudgetResult;
  link: LinkBudgetResult;
  thermal: ThermalResult;
  mass: MassBudgetResult;
  propulsion: PropulsionResult;
  cost: CostEstimateResult;
  overallFeasibility: 'feasible' | 'marginal' | 'infeasible';
  feasibilityScore: number; // 0-100
  recommendations: Array<{
    category: string;
    severity: 'info' | 'warning' | 'critical';
    message: { en: string; vi: string };
  }>;
}

export interface ScienceResult {
  scienceScore: number;         // 0-100
  dataCollectedPerDay: number;  // MB
  totalDataMission: number;     // GB
  missionLifetime: number;      // months
  spatialResolution?: number;   // m (for imaging)
  spectralResolution?: number;  // nm (for spectroscopy)
  coverage: number;             // % of target area
  dutyCycle: number;            // %
  discoveries: Array<{
    title: { en: string; vi: string };
    description: { en: string; vi: string };
    probability: number; // 0-1
  }>;
}

export interface MissionMatchResult {
  mission: import('./mission').NasaMission;
  overallScore: number;   // 0-100
  domainScore: number;    // 0-100
  wavelengthScore: number; // 0-100
  orbitScore: number;      // 0-100
  instrumentScore: number; // 0-100
  scaleScore: number;      // 0-100
  matchReasons: Array<{ en: string; vi: string }>;
}
